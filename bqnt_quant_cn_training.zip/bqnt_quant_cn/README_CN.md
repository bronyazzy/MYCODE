# Bloomberg BQNT 股票量化分析培训（中文）

## 文件

- `bqnt_quant_cn.ipynb`：正式培训用自包含Notebook，默认Bloomberg模式，无业绩输出。
- `bqnt_quant_cn.py`：相同逻辑的独立模块／脚本，可导入使用。
- `bqnt_quant_cn_SYNTHETIC.ipynb`：已执行的人工数据彩排，**不是Bloomberg数据或真实市场业绩**。
- `test_bqnt_quant_cn.py`：本地逻辑测试；不测试Bloomberg服务或权限。
- `VALIDATION.txt`：验证结果与范围。

## 使用

在已配置并有数据权限的BQuant Python内核打开正式Notebook，先检查参数并依次执行。
Notebook已包含所有函数，不需要同时上传`.py`。先运行单证券、单月份连接测试；
再运行完整案例。BQL请求必须在你的终端验证。

模块方式：将`bqnt_quant_cn.py`放在工作目录。

```python
import bqnt_quant_cn as q
from IPython.display import display

q.TOP_N = 5
q.COST_BPS = 10.0
q.BORROW_BPS = 100.0
q.DATA_START = "2018-01-01"
q.BACKTEST_START = "2020-01-01"
q.DATA_END = "2025-12-31"

demo = q.run_demo(mode="bloomberg", plot=True)
display(demo["metrics_cn"].round(3))
display(demo["ic_summary"].round(4))
display(demo["risk"].round(3))
```

离线彩排只需显式改用`mode="synthetic"`或打开模拟Notebook。取数失败时没有自动降级。
不得安装不明来源的同名`bql`包；使用你已授权环境中的Bloomberg实现。

依赖：NumPy、pandas、matplotlib；Notebook另用IPython。Bloomberg模式需要Bloomberg BQL。
测试采用本地现有环境，不要求你升级或改变终端管理的依赖版本。

## 演示设计

美股固定教学股票池20只，SPY作为参考。回测从2020-01-01到2025-12-31，预热从2018年开始。
均为历史日期，不是实时榜单。本示例默认同一市场与币种。

信号：12–1月动量近似、63日低波动、5日反转以及横截面排名50/30/20复合因子。
组合：动量波动率倒数加权、低波动等权、5日反转多空、复合因子等权；另有股票池等权与基准买入持有。
复合因子权重是事先规定的教学值，没有进行参数优化。

t日收盘生成信号；t+1日收盘成交；新仓此后贡献收益。旧仓获得执行日的收盘到收盘收益。
每月／每周调仓，权重自然漂移；使用扣费后净值确定目标市值。
买卖成交额均计费，初始建仓收费，末日不假设清仓。借券按前一日空头市值和实际日历日收费。
现金、无风险利率与其他融资收益设为0；不发送任何订单。

## 指标解释

- `metrics_cn`：净收益、CAGR、年化波动率、rf=0夏普、最大回撤、年均成交额/NAV。
- `risk`：数据末日风险快照，使用最近252个交易日收益。价格为调整后代理值。
- `factor_snapshot`：数据末日原始因子分数和复合百分位分数。
- `ic_summary`：5、21、63交易日横截面Rank IC；ICIR未年化。
- `quantiles`：复合分数五分组远期毛收益；Q1最低，Q5最高。最后一列为Q5-Q1全额收益差，不是50/50组合回报。
- `targets`：稀疏执行日目标权重，`attrs['signal_dates']`记录信号日。
- `holdings`：每日收盘、交易和扣费后的实际模型权重。

IC远期收益严格采用P[t+1+h]/P[t+1]-1；未完成窗口保留NaN。
日度窗口重叠，没有输出不合理的独立样本t值或年化ICIR。非重叠子样本每h个有效日期抽样，
只消除持有窗口重叠，不能保证因子或样本在统计上独立。五分组诊断并非成本后可执行净值。

## 上线限制与排错

`PX_LAST(ca_adj="FULL", fill="NA")`以及`PX_VOLUME`参数需对照本机BQL帮助。
价格只被标记为调整后收益代理，不保证与经验证的含息总回报指数相同。
严格校验缺失值和重复观测，禁止用未来值回填、静默删股或把缺失收益改成0。
基准成交量筛选交易日只用于同市场示例，不替代正式交易所日历或停牌模型。

固定事后股票池有样本选择／幸存者偏差；未模拟退市、汇率、容量、保证金、税、
真实借券可得性和非线性市场冲击。反转策略仅调仓时金额中性，不是Beta中性。
实际研究需点时可投资股票池、独立样本外验证及可执行交易与风险模型。

## 参考资料

- Bloomberg BQuant：https://professional.bloomberg.com/products/bloomberg-terminal/research/bquant/
- pandas收益计算：https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.pct_change.html
- pandas排名：https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.rank.html
- pandas相关：https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.corrwith.html
- Kenneth French动量构造：https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/det_mom_factor.html
