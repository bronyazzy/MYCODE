"""Bloomberg BQNT 股票量化分析培训（中文版）。

用途：BQL 取数、风险分析、因子检验、组合回测、成本敏感性实验。
不连接交易接口，不发送订单。默认 Bloomberg 模式；模拟模式必须显式选择。
本地验证不包含 Bloomberg 连接、数据权限与字段参数的实机验证。
"""

# %% 1. 导入与培训参数
from typing import Dict, Sequence, Tuple
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

TICKERS = [
    "AAPL US Equity", "MSFT US Equity", "AMZN US Equity", "GOOGL US Equity",
    "META US Equity", "NVDA US Equity", "JPM US Equity", "BAC US Equity",
    "XOM US Equity", "CVX US Equity", "JNJ US Equity", "MRK US Equity",
    "UNH US Equity", "PG US Equity", "KO US Equity", "PEP US Equity",
    "WMT US Equity", "COST US Equity", "HD US Equity", "MCD US Equity",
]
BENCHMARK = "SPY US Equity"
DATA_START = "2018-01-01"       # 信号预热数据，不从回测开始日才取数
BACKTEST_START = "2020-01-01"
DATA_END = "2025-12-31"         # 固定历史截止日，不代表最新行情
TOP_N = 5                     # 多头持股数；多空策略每侧股票数
COST_BPS = 10.0                # 单边每笔成交额成本；1 bp = 0.01%
BORROW_BPS = 100.0             # 空头市值的假设年化借券费；不是实时市场报价
DATA_MODE = "bloomberg"        # 离线彩排请显式改为 "synthetic"
MIN_IC_NAMES = 10              # 单日 Rank IC 至少需要的有效股票数
IC_HORIZONS = (5, 21, 63)      # 从次日收盘开始持有的交易日数

STRATEGY_CN = {
    "momentum": "动量／波动率倒数加权",
    "low_vol": "低波动／等权",
    "reversal_ls": "5日反转／多空",
    "composite": "复合因子／等权",
    "equal_weight": "股票池等权",
    "benchmark": "基准买入持有",
}
METRIC_CN = {
    "Total return %": "累计收益（%）",
    "CAGR %": "年化复合收益（%）",
    "Annual volatility %": "年化波动率（%）",
    "Sharpe (rf=0)": "夏普比率（rf=0）",
    "Max drawdown %": "最大回撤（%）",
    "Traded notional / NAV / year": "年均成交额／NAV",
}


# %% 2. Bloomberg 数据适配与严格校验

def _pivot_item(item, value_name: str) -> pd.DataFrame:
    """将单个 BQL 响应转换为“日期 × 证券”矩阵；重复记录直接报错。"""
    frame = item.df().reset_index()
    needed = {"ID", "DATE", value_name}
    if not needed.issubset(frame.columns):
        raise ValueError(
            "Unexpected BQL response columns: {}. Expected {}. Inspect the "
            "response in your BQuant environment.".format(list(frame.columns), needed)
        )
    frame["DATE"] = pd.to_datetime(frame["DATE"], errors="raise").dt.tz_localize(None)
    frame[value_name] = pd.to_numeric(frame[value_name], errors="coerce")
    if frame["DATE"].isna().any() or frame.duplicated(["DATE", "ID"]).any():
        raise ValueError("BQL returned missing dates or duplicate ID/date observations.")
    return frame.pivot(index="DATE", columns="ID", values=value_name).sort_index()


def validate_prices(prices: pd.DataFrame) -> None:
    """严格检查价格：不补未来值、不删除缺失股票、不把缺失收益替换为零。"""
    if not isinstance(prices.index, pd.DatetimeIndex):
        raise TypeError("Prices need a DatetimeIndex.")
    if not prices.index.is_unique or not prices.index.is_monotonic_increasing:
        raise ValueError("Price dates must be unique and sorted.")
    if not prices.columns.is_unique or prices.empty or len(prices) < 3:
        raise ValueError("Need nonempty prices, unique securities, and at least 3 dates.")
    bad = ~np.isfinite(prices.to_numpy(dtype=float)) | (prices.to_numpy(dtype=float) <= 0)
    if bad.any():
        examples = [(str(prices.index[i].date()), str(prices.columns[j]))
                    for i, j in np.argwhere(bad)[:8]]
        raise ValueError(
            "Missing/nonpositive prices on benchmark sessions: {}. Fix the source "
            "data; do not backfill, silently drop names, or replace returns by zero."
            .format(examples)
        )


def bloomberg_prices(tickers: Sequence[str], benchmark: str,
                     start: str, end: str, batch_size: int = 5) -> pd.DataFrame:
    """请求 CA_ADJ=FULL 的价格，并以基准成交量为正的日期对齐交易日。

    返回值是调整后价格的收益代理，不宣称是经核验的含息总回报指数。
    请在本机 BQL 字段帮助核查 PX_LAST、PX_VOLUME、CA_ADJ 和 FILL。
    取数失败时绝不自动改用未调整价格或模拟数据。
    该交易日处理适用于本例同市场股票，不是跨市场日历或停牌处理系统。"""
    if (not tickers or benchmark in tickers or len(set(tickers)) != len(tickers)):
        raise ValueError("股票代码必须唯一、非空，且不包含基准。")
    if batch_size < 1 or pd.Timestamp(start) >= pd.Timestamp(end):
        raise ValueError("Need batch_size >= 1 and start < end.")
    try:
        import bql
    except ImportError as exc:
        raise RuntimeError(
            "Bloomberg's bql package is required in your entitled BQuant kernel. "
            "Use DATA_MODE='synthetic' only for a clearly labelled offline rehearsal."
        ) from exc
    ids = list(dict.fromkeys(list(tickers) + [benchmark]))
    try:
        bq = bql.Service()
        dates = bq.func.range(start, end)
        price_item = bq.data.px_last(dates=dates, ca_adj="FULL", fill="NA")
        parts = []
        for first in range(0, len(ids), batch_size):
            request = bql.Request(ids[first:first + batch_size], {"PRICE": price_item})
            response = bq.execute(request)
            parts.append(_pivot_item(response[0], "PRICE"))
        volume_request = bql.Request(
            [benchmark], {"VOLUME": bq.data.px_volume(dates=dates, fill="NA")}
        )
        volume = _pivot_item(bq.execute(volume_request)[0], "VOLUME")[benchmark]
    except Exception as exc:
        raise RuntimeError(
            "Bloomberg retrieval failed. Inspect the original exception below, your "
            "entitlements and local BQL field help for PX_LAST / PX_VOLUME / "
            "CA_ADJ / FILL. Try a single ticker first. No data substitute was used."
        ) from exc
    # 用基准成交量筛选教学用交易日，再严格检查所有股票的价格。
    sessions = volume.loc[start:end].index[volume.loc[start:end].gt(0)]
    if len(sessions) < 3:
        raise ValueError("Insufficient benchmark trading sessions in the response.")
    prices = pd.concat(parts, axis=1).reindex(index=sessions, columns=ids).astype(float)
    validate_prices(prices)
    prices.attrs["data_label"] = "Bloomberg adjusted-price proxy"
    return prices


# %% 3. 明确标注的模拟数据，仅供离线彩排

def synthetic_prices(tickers: Sequence[str], benchmark: str,
                     start: str, end: str, seed: int = 7) -> pd.DataFrame:
    """生成具有共同市场因子的人工价格，不是 Bloomberg 行情或历史业绩。

    使用普通工作日，不模拟真实交易所节假日。随机种子固定以便复现。"""
    if benchmark in tickers or len(set(tickers)) != len(tickers):
        raise ValueError("Use unique stock IDs, excluding the benchmark.")
    rng = np.random.RandomState(seed)
    dates = pd.bdate_range(start, end)
    n = len(tickers)
    market = rng.normal(0.00025, 0.010, len(dates))
    beta = np.linspace(0.65, 1.35, n)
    idio_vol = np.linspace(0.007, 0.021, n)
    stock_logs = (market[:, None] * beta + 0.00008
                  + rng.normal(size=(len(dates), n)) * idio_vol)
    stock_logs[0, :] = 0.0
    market[0] = 0.0
    prices = pd.DataFrame(100.0 * np.exp(np.cumsum(stock_logs, axis=0)),
                          index=dates, columns=list(tickers))
    prices[benchmark] = 100.0 * np.exp(np.cumsum(market))
    prices.attrs["data_label"] = "SYNTHETIC rehearsal - NOT market performance"
    validate_prices(prices)
    return prices


# %% 4. 因子计算、个股风险与横截面排名

def factor_panel(prices: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    """只使用当日及此前数据；所有分数统一为越高越优先。

    复合权重 50/30/20 是事先规定的教学假设，并非历史优化结果。
    """
    validate_prices(prices)
    ret = prices.pct_change(fill_method=None)
    vol = ret.rolling(63, min_periods=63).std(ddof=1) * np.sqrt(252)
    momentum = (prices.shift(21) / prices.shift(252) - 1).where(vol > 0)
    low_vol = (-vol).where(vol > 0)
    reversal = -prices.pct_change(5, fill_method=None)
    composite = (
        0.50 * momentum.rank(axis=1, method="average", pct=True)
        + 0.30 * low_vol.rank(axis=1, method="average", pct=True)
        + 0.20 * reversal.rank(axis=1, method="average", pct=True)
    )
    return {
        "momentum": momentum,
        "low_vol": low_vol,
        "reversal_ls": reversal,
        "composite": composite,
    }


def risk_snapshot(data: pd.DataFrame, tickers: Sequence[str],
                  benchmark: str, window: int = 252) -> pd.DataFrame:
    """截至数据最后一日的历史风险快照；Beta 与相关系数使用同一收益窗口。"""
    validate_prices(data)
    if not isinstance(window, int) or window < 2 or len(data) < window + 1:
        raise ValueError("风险窗口至少为2，且需要 window+1 个价格观察值。")
    p = data.loc[:, list(tickers)]
    recent_prices = p.iloc[-(window + 1):]
    returns = data.pct_change(fill_method=None).iloc[-window:]
    stocks, market = returns.loc[:, list(tickers)], returns[benchmark]
    market_var = market.var(ddof=1)
    beta = stocks.apply(lambda r: r.cov(market) / market_var) if market_var > 0 else pd.Series(np.nan, index=tickers)
    report = pd.DataFrame({
        "最后调整价格": p.iloc[-1],
        "窗口收益（%）": 100 * (recent_prices.iloc[-1] / recent_prices.iloc[0] - 1),
        "年化波动率（%）": 100 * stocks.std(ddof=1) * np.sqrt(252),
        "Beta": beta,
        "与基准相关系数": stocks.corrwith(market),
        "窗口最大回撤（%）": 100 * (recent_prices / recent_prices.cummax() - 1).min(),
    })
    report.attrs.update(as_of=str(data.index[-1].date()), window_sessions=window)
    return report


def factor_snapshot(factors: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    """历史截止日的因子值与复合分数，不是实时荐股或交易指令。"""
    result = pd.DataFrame({name: frame.iloc[-1] for name, frame in factors.items()})
    result = result.sort_values("composite", ascending=False, kind="mergesort")
    result.attrs["as_of"] = str(next(iter(factors.values())).index[-1].date())
    return result


# %% 5. Rank IC：信号与未来收益严格隔离

def forward_returns(prices: pd.DataFrame, horizon: int = 21) -> pd.DataFrame:
    """t日信号，t+1日收盘执行，持有h日：P[t+1+h]/P[t+1]-1。

    此函数只用于事后评价，不可放进选股或交易信号。尾部没有完整未来
    窗口的行保留为NaN，不以零代替。
    """
    validate_prices(prices)
    if not isinstance(horizon, int) or horizon < 1:
        raise ValueError("horizon 必须是正整数。")
    return prices.shift(-(horizon + 1)) / prices.shift(-1) - 1


def rank_ic(score: pd.DataFrame, future_return: pd.DataFrame,
            min_names: int = 10) -> pd.Series:
    """逐日横截面 Spearman 相关：先对成对有效值排名，再求 Pearson 相关。"""
    if (not score.index.equals(future_return.index)
            or not score.columns.equals(future_return.columns)):
        raise ValueError("因子和未来收益必须具有完全相同的日期与股票列。")
    if not isinstance(min_names, int) or min_names < 3:
        raise ValueError("min_names 至少为3。")
    valid = np.isfinite(score) & np.isfinite(future_return)
    x = score.where(valid).rank(axis=1, method="average")
    y = future_return.where(valid).rank(axis=1, method="average")
    # 去均值后计算相关，避免额外依赖 scipy；常数横截面返回NaN。
    x = x.sub(x.mean(axis=1), axis=0)
    y = y.sub(y.mean(axis=1), axis=0)
    denom = np.sqrt(x.pow(2).sum(axis=1) * y.pow(2).sum(axis=1))
    ic = (x.mul(y).sum(axis=1) / denom.where(denom > 0))
    return ic.where(valid.sum(axis=1) >= min_names).rename("Rank IC")


def factor_diagnostics(prices: pd.DataFrame,
                       factors: Dict[str, pd.DataFrame], start: str,
                       horizons: Sequence[int] = (5, 21, 63),
                       min_names: int = 10) -> Tuple[pd.DataFrame, dict]:
    """返回IC汇总和各因子/窗口的日度IC。

    日度远期收益相互重叠；不输出未经自相关调整的t值或年化ICIR。
    每隔h个有效信号抽样，额外提供不重叠持有窗口的IC均值；不代表独立。
    """
    rows, curves = [], {}
    for h in horizons:
        future = forward_returns(prices, h)
        for name, score in factors.items():
            curve = rank_ic(score, future, min_names).loc[start:]
            sample = curve.dropna()
            if sample.empty:
                raise ValueError("没有足够的有效IC样本：{} / {}日。".format(name, h))
            nonoverlap = sample.iloc[::h]
            sd = sample.std(ddof=1)
            rows.append({
                "因子": name, "持有交易日": h,
                "平均Rank IC": sample.mean(),
                "IC标准差": sd,
                "ICIR（未年化）": sample.mean() / sd if sd > 0 else np.nan,
                "IC正值比例": (sample > 0).mean(),
                "日度样本数": len(sample),
                "非重叠IC均值": nonoverlap.mean(),
                "非重叠样本数": len(nonoverlap),
            })
            curves[(name, h)] = curve
    return pd.DataFrame(rows).set_index(["因子", "持有交易日"]), curves


def quantile_forward_returns(prices: pd.DataFrame, score: pd.DataFrame,
                             start: str, horizon: int = 21,
                             groups: int = 5) -> pd.DataFrame:
    """逐日按分数分组，统计组内等权远期毛收益；Q1最低，Q5最高。

    这是重叠持有窗口的诊断表，不是可直接复利的净值或成本后回测。
    并列分数按输入股票列顺序拆分，未来收益绝不参与分组。
    """
    future = forward_returns(prices, horizon)
    if not score.index.equals(prices.index) or not score.columns.equals(prices.columns):
        raise ValueError("score 必须与 prices 完全对齐。")
    if not isinstance(groups, int) or groups < 2:
        raise ValueError("groups 至少为2。")
    valid = np.isfinite(score) & np.isfinite(future)
    count = valid.sum(axis=1)
    ranks = score.where(valid).rank(axis=1, method="first")
    bucket = np.floor((ranks - 1).mul(groups).div(count.replace(0, np.nan), axis=0)) + 1
    out = pd.DataFrame({
        "Q{}".format(g): future.where(bucket == g).mean(axis=1)
        for g in range(1, groups + 1)
    }).where(count >= groups).loc[start:]
    out["Q{}-Q1".format(groups)] = out["Q{}".format(groups)] - out["Q1"]
    return out



# %% 6. 组合构建与带成本回测

def make_targets(prices: pd.DataFrame, strategy: str, start: str,
                 top_n: int = 5) -> pd.DataFrame:
    """构造稀疏目标权重，行索引是执行日收盘，不是信号日。

    t日收盘信号 -> t+1日收盘执行 -> 新仓从t+1至t+2开始贡献收益。
    月调仓用新月首个交易日；反转策略每个W-FRI周的首个交易日执行。
    回测首日也执行建仓。动量用波动率倒数加权，其余多头用等权。
    多空反转在调仓时为50%多头、50%空头，不宣称Beta中性。"""
    allowed = {"momentum", "low_vol", "reversal_ls", "composite", "equal_weight", "buy_hold"}
    if strategy not in allowed or not isinstance(top_n, int) or top_n < 1:
        raise ValueError("Unknown strategy or invalid top_n.")
    validate_prices(prices)
    idx = prices.index
    evaluation = np.flatnonzero(idx >= pd.Timestamp(start))
    if len(evaluation) == 0 or evaluation[0] == 0:
        raise ValueError("Need evaluation dates plus at least one earlier observation.")
    daily = prices.pct_change(fill_method=None)
    vol = daily.rolling(63, min_periods=63).std(ddof=1) * np.sqrt(252)
    scores = factor_panel(prices)
    period = idx.to_period("W-FRI" if strategy == "reversal_ls" else "M")
    rows, execution_dates, signal_dates = [], [], {}
    for i in evaluation:
        if rows and (strategy == "buy_hold" or period[i] == period[i - 1]):
            continue
        w = pd.Series(0.0, index=prices.columns)
        if strategy in {"equal_weight", "buy_hold"}:
            w[:] = 1.0 / len(w)
        else:
            # 只读取执行日前一交易日的信号，绝不读取执行日收盘信号。
            ranked = scores[strategy].iloc[i - 1].dropna().sort_values(
                ascending=False, kind="mergesort"
            )
            needed = 2 * top_n if strategy == "reversal_ls" else top_n
            if len(ranked) < needed:
                raise ValueError("Insufficient signal history/names at {}.".format(idx[i - 1]))
            chosen = ranked.index[:top_n]
            if strategy == "momentum":
                inverse_vol = 1.0 / vol.iloc[i - 1].loc[chosen]
                w.loc[chosen] = inverse_vol / inverse_vol.sum()
            elif strategy in {"low_vol", "composite"}:
                w.loc[chosen] = 1.0 / top_n
            else:
                w.loc[chosen] = 0.5 / top_n             # 多头：近期下跌者。
                w.loc[ranked.index[-top_n:]] = -0.5 / top_n  # 空头：近期上涨者。
        rows.append(w)
        execution_dates.append(idx[i])
        signal_dates[idx[i]] = idx[i - 1]
    targets = pd.DataFrame(rows, index=pd.DatetimeIndex(execution_dates), columns=prices.columns)
    targets.index.name = "execution_date"
    targets.attrs["signal_dates"] = signal_dates
    return targets


def backtest(prices: pd.DataFrame, targets: pd.DataFrame, start: str,
             cost_bps: float = 10.0, borrow_bps: float = 100.0
             ) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """自融资的调整收益代理账本；初始净值1，初始全部现金。

    持仓为带正负号的市值，不是实际可执行的股数。非调仓日随价格漂移。
    费用从资产中扣除，目标权重以扣费后净值计；现金收益和无风险利率为0。
    借券费按上一日空头市值和实际日历日/365累计。
    不模拟冲击、税、保证金、其他融资或借券可得性；末日不强制清仓。"""
    validate_prices(prices)
    if not np.isfinite([cost_bps, borrow_bps]).all() or min(cost_bps, borrow_bps) < 0:
        raise ValueError("Costs must be finite and nonnegative.")
    if (not targets.columns.equals(prices.columns) or not targets.index.is_unique
            or not targets.index.isin(prices.index).all() or targets.empty
            or not np.isfinite(targets.to_numpy(dtype=float)).all()):
        raise ValueError("Targets must be finite, unique, and aligned to price dates/columns.")
    first = prices.index.searchsorted(pd.Timestamp(start))
    if first < 1 or first >= len(prices):
        raise ValueError("Need an evaluation period and a prior price observation.")
    if (targets.index < prices.index[first]).any():
        raise ValueError("Targets cannot precede the evaluation period.")
    fee_rate, borrow_rate = cost_bps / 10000.0, borrow_bps / 10000.0
    if fee_rate * targets.abs().sum(axis=1).max() >= 1:
        raise ValueError("Transaction fee / target leverage is too large.")
    target_map = {date: row.to_numpy(dtype=float) for date, row in targets.iterrows()}
    r = prices.pct_change(fill_method=None).to_numpy(dtype=float)
    position, cash = np.zeros(prices.shape[1]), 1.0
    records, weights = [], []
    for i in range(first, len(prices)):
        date = prices.index[i]
        old_nav = cash + position.sum()
        days = (date - prices.index[i - 1]).days
        borrow_fee = -np.minimum(position, 0).sum() * borrow_rate * days / 365.0
        position *= 1.0 + r[i]   # 先由旧仓获得当日收益，再在收盘交易。
        cash -= borrow_fee
        pre_trade_nav = cash + position.sum()
        if pre_trade_nav <= 0:
            raise RuntimeError("Portfolio equity is exhausted at {}.".format(date))
        traded, fee = 0.0, 0.0
        if date in target_map:
            target = target_map[date]
            # 求解扣费后净值，确保目标持仓和交易费用共同满足自融资。
            # 避免100%多头组合扣费后出现未披露的负现金。
            post_nav = pre_trade_nav
            for _ in range(100):
                updated = pre_trade_nav - fee_rate * np.abs(target * post_nav - position).sum()
                if updated <= 0:
                    raise RuntimeError("Rebalance costs exhaust portfolio equity.")
                converged = abs(updated - post_nav) <= 1e-12 * pre_trade_nav
                post_nav = updated
                if converged:
                    break
            else:
                raise RuntimeError("Post-cost sizing did not converge.")
            new_position = target * post_nav
            traded = np.abs(new_position - position).sum()
            fee = fee_rate * traded
            cash = pre_trade_nav - fee - new_position.sum()
            position = new_position
        nav = cash + position.sum()
        records.append({
            "nav": nav, "return": nav / old_nav - 1,
            "turnover": traded / pre_trade_nav,
            "trade_cost": fee / old_nav, "borrow_cost": borrow_fee / old_nav,
            "gross": np.abs(position).sum() / nav, "net": position.sum() / nav,
            "rebalance": date in target_map,
        })
        weights.append(position.copy() / nav)
    dates = prices.index[first:]
    result = pd.DataFrame(records, index=dates)
    result.attrs["initial_date"] = prices.index[first - 1]
    holdings = pd.DataFrame(weights, index=dates, columns=prices.columns)
    return result, holdings


# %% 7. 绩效统计与净值／回撤图

def performance(result: pd.DataFrame) -> pd.Series:
    """统计净收益、自然日年化CAGR、252交易日年化波动、夏普、回撤及成交强度。"""
    r, nav = result["return"], result["nav"]
    years = (result.index[-1] - result.attrs["initial_date"]).days / 365.25
    sd = r.std(ddof=1)
    # 将建仓前净值1纳入峰值，初始交易成本造成的回撤不会消失。
    peak = np.maximum.accumulate(np.r_[1.0, nav.to_numpy()])[1:]
    return pd.Series({
        "Total return %": 100 * (nav.iloc[-1] - 1),
        "CAGR %": 100 * (nav.iloc[-1] ** (1.0 / years) - 1),
        "Annual volatility %": 100 * sd * np.sqrt(252),
        "Sharpe (rf=0)": np.sqrt(252) * r.mean() / sd if sd > 0 else np.nan,
        "Max drawdown %": 100 * (nav.to_numpy() / peak - 1).min(),
        "Traded notional / NAV / year": result["turnover"].sum() / years,
    })


def plot_results(results: Dict[str, pd.DataFrame], data_label: str) -> None:
    curve = pd.DataFrame({name: result["nav"] for name, result in results.items()})
    initial_date = next(iter(results.values())).attrs["initial_date"]
    baseline = pd.DataFrame(1.0, index=[initial_date], columns=curve.columns)
    curve = pd.concat([baseline, curve]).sort_index()
    fig, ax = plt.subplots(figsize=(12, 5))
    curve.plot(ax=ax)
    ax.set(title=data_label + " | net NAV", ylabel="Growth of 1", xlabel="Date")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    plt.show()
    fig, ax = plt.subplots(figsize=(12, 4))
    (100 * (curve / curve.cummax() - 1)).plot(ax=ax)
    ax.set(title=data_label + " | drawdowns", ylabel="Drawdown (%)", xlabel="Date")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    plt.show()


# %% 8. 运行完整培训案例

def run_demo(mode: str = "bloomberg", plot: bool = True,
             verbose: bool = True) -> dict:
    """返回行情、因子、IC、风险表、净值、目标权重及每日收盘持仓。"""
    if not (pd.Timestamp(DATA_START) < pd.Timestamp(BACKTEST_START) < pd.Timestamp(DATA_END)):
        raise ValueError("需要 DATA_START < BACKTEST_START < DATA_END。")
    if (len(set(TICKERS)) != len(TICKERS) or BENCHMARK in TICKERS
            or len(TICKERS) < max(2 * TOP_N, MIN_IC_NAMES)):
        raise ValueError("股票代码需唯一，不含基准，且数量至少为max(2*TOP_N, MIN_IC_NAMES)。")
    if mode == "bloomberg":
        data = bloomberg_prices(TICKERS, BENCHMARK, DATA_START, DATA_END)
    elif mode == "synthetic":
        data = synthetic_prices(TICKERS, BENCHMARK, DATA_START, DATA_END)
    else:
        raise ValueError("mode 只能是 'bloomberg' 或 'synthetic'。")
    prices = data.loc[:, TICKERS]
    factors = factor_panel(prices)
    ic_summary, ic_curves = factor_diagnostics(
        prices, factors, BACKTEST_START, IC_HORIZONS, MIN_IC_NAMES
    )
    results, targets, holdings = {}, {}, {}
    for name in ("momentum", "low_vol", "reversal_ls", "composite", "equal_weight", "benchmark"):
        px = data.loc[:, [BENCHMARK]] if name == "benchmark" else prices
        rule = "buy_hold" if name == "benchmark" else name
        targets[name] = make_targets(px, rule, BACKTEST_START, TOP_N)
        results[name], holdings[name] = backtest(
            px, targets[name], BACKTEST_START, COST_BPS, BORROW_BPS
        )
    metrics = pd.DataFrame({name: performance(r) for name, r in results.items()}).T
    metrics_cn = metrics.rename(index=STRATEGY_CN, columns=METRIC_CN)
    if verbose:
        print(data.attrs["data_label"])
        print("历史区间：{} 至 {}；预热始于 {}。".format(BACKTEST_START, DATA_END, DATA_START))
        print("固定事后选定股票池；这不是无幸存者偏差的研究。")
        print("单边交易成本 {} bps；年化借券费 {} bps；现金/rf = 0%。".format(COST_BPS, BORROW_BPS))
        print(metrics_cn.round(3).to_string())
    if plot:
        plot_results(results, data.attrs["data_label"])
    return {
        "data": data, "factors": factors,
        "factor_snapshot": factor_snapshot(factors),
        "risk": risk_snapshot(data, TICKERS, BENCHMARK),
        "correlation": data.pct_change(fill_method=None).iloc[-252:].corr(),
        "ic_summary": ic_summary, "ic_curves": ic_curves,
        "quantiles": quantile_forward_returns(prices, factors["composite"], BACKTEST_START),
        "targets": targets, "results": results, "holdings": holdings,
        "metrics": metrics, "metrics_cn": metrics_cn,
    }


def cost_sensitivity(prices: pd.DataFrame, strategy: str = "reversal_ls",
                     start: str = "2020-01-01", top_n: int = 5,
                     cost_grid: Sequence[float] = (0, 5, 10, 25),
                     borrow_bps: float = 100.0) -> pd.DataFrame:
    """固定数据和信号，只改变交易成本；不重新请求 Bloomberg。"""
    targets = make_targets(prices, strategy, start, top_n)
    records = {}
    for cost in cost_grid:
        result, _ = backtest(prices, targets, start, cost, borrow_bps)
        records[float(cost)] = performance(result)
    return pd.DataFrame(records).T.rename_axis("单边成本（bps）").rename(columns=METRIC_CN)


def plot_factor_diagnostics(demo: dict, horizon: int = 21) -> None:
    """每张图独立绘制；英文图例避免培训内核缺少中文字体。"""
    label = demo["data"].attrs["data_label"]
    curves = {name: curve.rolling(63, min_periods=30).mean()
              for (name, h), curve in demo["ic_curves"].items() if h == horizon}
    if not curves:
        raise ValueError("请求的IC窗口没有计算。")
    fig, ax = plt.subplots(figsize=(12, 4))
    pd.DataFrame(curves).plot(ax=ax)
    ax.axhline(0, linewidth=0.8, linestyle="--")
    ax.set(title=label + " | {}-session Rank IC, 63-session mean".format(horizon),
           xlabel="Signal date", ylabel="Rank IC")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    plt.show()
    fig, ax = plt.subplots(figsize=(10, 4))
    (100 * demo["quantiles"].mean()).plot.bar(ax=ax, rot=0)
    ax.set(title=label + " | Composite: overlapping 21-session gross returns",
           xlabel="Q1 lowest score; Q5 highest score", ylabel="Mean forward return (%)")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    plt.show()


# 作为脚本运行时默认连接 Bloomberg；导入模块时不会自动请求行情。
if __name__ == "__main__":
    demo = run_demo(DATA_MODE)
