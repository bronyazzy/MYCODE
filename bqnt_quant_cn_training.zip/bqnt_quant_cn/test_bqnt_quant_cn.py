"""本地逻辑测试。全部使用人工数据；不验证 Bloomberg 服务器或数据权限。"""
import unittest
import numpy as np
import pandas as pd
import bqnt_quant_cn as q


class QuantTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = q.synthetic_prices(q.TICKERS, q.BENCHMARK, q.DATA_START, q.DATA_END)
        cls.prices = cls.data[q.TICKERS]
        cls.factors = q.factor_panel(cls.prices)

    def flat(self, columns=("A", "B")):
        return pd.DataFrame(100.0, index=pd.bdate_range("2020-01-01", periods=5), columns=list(columns))

    def test_01_synthetic_reproducibility(self):
        again = q.synthetic_prices(q.TICKERS, q.BENCHMARK, q.DATA_START, q.DATA_END)
        pd.testing.assert_frame_equal(self.data, again)
        self.assertIn("SYNTHETIC", self.data.attrs["data_label"])

    def test_02_synthetic_rejects_duplicates(self):
        with self.assertRaises(ValueError):
            q.synthetic_prices(["A", "A"], "B", "2020-01-01", "2020-12-31")

    def test_03_missing_price_fails(self):
        p = self.flat()
        p.iloc[2, 0] = np.nan
        with self.assertRaises(ValueError):
            q.validate_prices(p)

    def test_04_nonpositive_price_fails(self):
        p = self.flat()
        p.iloc[2, 0] = 0.0
        with self.assertRaises(ValueError):
            q.validate_prices(p)

    def test_05_unsorted_dates_fail(self):
        with self.assertRaises(ValueError):
            q.validate_prices(self.flat().iloc[::-1])

    def test_06_bql_pivot_schema_only(self):
        class FakeItem:
            def df(self):
                return pd.DataFrame({"ID": ["A", "B"], "DATE": ["2020-01-02"] * 2,
                                     "PRICE": [10.0, 20.0]}).set_index("ID")
        p = q._pivot_item(FakeItem(), "PRICE")
        self.assertEqual(p.loc[pd.Timestamp("2020-01-02"), "B"], 20.0)

    def test_07_bql_duplicate_observation_fails(self):
        class FakeItem:
            def df(self):
                return pd.DataFrame({"ID": ["A", "A"], "DATE": ["2020-01-02"] * 2,
                                     "PRICE": [10.0, 20.0]}).set_index("ID")
        with self.assertRaises(ValueError):
            q._pivot_item(FakeItem(), "PRICE")

    def test_08_factors_use_no_future_prices(self):
        p = self.prices.copy()
        cut = 900
        p.iloc[cut + 1:] *= np.linspace(0.7, 2.1, p.shape[1])
        changed = q.factor_panel(p)
        for name in changed:
            pd.testing.assert_frame_equal(self.factors[name].iloc[:cut + 1], changed[name].iloc[:cut + 1])

    def test_09_momentum_formula(self):
        t = 800
        expected = self.prices.iloc[t - 21] / self.prices.iloc[t - 252] - 1
        np.testing.assert_allclose(self.factors["momentum"].iloc[t], expected)

    def test_10_composite_bounds(self):
        valid = self.factors["composite"].dropna()
        self.assertTrue((valid.to_numpy() > 0).all())
        self.assertTrue((valid.to_numpy() <= 1).all())

    def test_11_rank_ic_positive_with_ties(self):
        x = pd.DataFrame([[1., 2., 2., 4., 5.]])
        self.assertAlmostEqual(q.rank_ic(x, 3 * x + 1, min_names=3).iloc[0], 1)

    def test_12_rank_ic_negative_and_missing_pairs(self):
        x = pd.DataFrame([[1., 2., np.nan, 4., 5.]])
        y = pd.DataFrame([[5., 4., 3., 2., 1.]])
        self.assertAlmostEqual(q.rank_ic(x, y, min_names=3).iloc[0], -1)

    def test_13_rank_ic_constant_is_nan(self):
        x = pd.DataFrame([[1., 1., 1., 1., 1.]])
        y = pd.DataFrame([[1., 2., 3., 4., 5.]])
        self.assertTrue(np.isnan(q.rank_ic(x, y, min_names=3).iloc[0]))

    def test_14_rank_ic_min_names(self):
        x = pd.DataFrame([[1., 2., 3., np.nan, np.nan]])
        self.assertTrue(np.isnan(q.rank_ic(x, x, min_names=4).iloc[0]))

    def test_15_forward_return_excludes_execution_day(self):
        p = pd.DataFrame({"A": [100., 110., 220., 242., 266.2]},
                         index=pd.bdate_range("2020-01-01", periods=5))
        f = q.forward_returns(p, horizon=1)
        self.assertAlmostEqual(f.iloc[0, 0], 1.0)  # P2/P1, not P1/P0
        self.assertTrue(f.iloc[-2:].isna().all().all())

    def test_16_execution_day_signal_not_used(self):
        base = q.make_targets(self.prices, "composite", q.BACKTEST_START, 5)
        date = base.index[0]
        altered = self.prices.copy()
        altered.loc[date] *= np.linspace(0.1, 10, altered.shape[1])
        changed = q.make_targets(altered, "composite", q.BACKTEST_START, 5)
        pd.testing.assert_series_equal(base.loc[date], changed.loc[date])
        self.assertLess(base.attrs["signal_dates"][date], date)

    def test_17_long_only_weights(self):
        for rule in ("momentum", "low_vol", "composite"):
            target = q.make_targets(self.prices, rule, q.BACKTEST_START, 5)
            np.testing.assert_allclose(target.sum(axis=1), 1.0)
            self.assertTrue((target.ge(0)).all().all())
            self.assertTrue((target.ne(0).sum(axis=1) == 5).all())

    def test_18_long_short_target_exposure(self):
        target = q.make_targets(self.prices, "reversal_ls", q.BACKTEST_START, 5)
        np.testing.assert_allclose(target.sum(axis=1), 0.0, atol=1e-12)
        np.testing.assert_allclose(target.abs().sum(axis=1), 1.0)
        self.assertTrue((target.gt(0).sum(axis=1) == 5).all())
        self.assertTrue((target.lt(0).sum(axis=1) == 5).all())

    def test_19_initial_trade_is_self_financing(self):
        p = self.flat()
        t = pd.DataFrame([[0.5, 0.5]], index=p.index[[1]], columns=p.columns)
        r, w = q.backtest(p, t, str(p.index[1].date()), 10, 0)
        self.assertAlmostEqual(r["nav"].iloc[0], 1 / 1.001, places=12)
        np.testing.assert_allclose(w.sum(axis=1), 1.0, atol=1e-12)
        self.assertLess(q.performance(r)["Max drawdown %"], 0)

    def test_20_new_holding_starts_after_execution_close(self):
        p = pd.DataFrame({"A": [100., 200., 220., 242., 266.2]},
                         index=pd.bdate_range("2020-01-01", periods=5))
        t = pd.DataFrame([[1.]], index=p.index[[1]], columns=p.columns)
        r, _ = q.backtest(p, t, str(p.index[1].date()), 0, 0)
        self.assertAlmostEqual(r["nav"].iloc[0], 1.)
        self.assertAlmostEqual(r["nav"].iloc[1], 1.1)

    def test_21_holdings_drift_without_rebalancing(self):
        p = self.flat()
        p.loc[p.index[2]:, "A"] = 200.
        t = pd.DataFrame([[0.5, 0.5]], index=p.index[[1]], columns=p.columns)
        r, w = q.backtest(p, t, str(p.index[1].date()), 0, 0)
        self.assertAlmostEqual(w.iloc[1, 0], 2 / 3)
        self.assertEqual(int(r["rebalance"].sum()), 1)

    def test_22_borrow_accrues_by_calendar_day(self):
        p = pd.DataFrame(100., index=pd.to_datetime(["2020-01-02", "2020-01-03", "2020-01-06"]), columns=["A", "B"])
        t = pd.DataFrame([[0.5, -0.5]], index=p.index[[1]], columns=p.columns)
        r, _ = q.backtest(p, t, "2020-01-03", 0, 100)
        self.assertAlmostEqual(r["nav"].iloc[-1], 1 - 0.5 * 0.01 * 3 / 365)

    def test_23_invalid_cost_fails(self):
        p = self.flat()
        t = pd.DataFrame([[0.5, 0.5]], index=p.index[[1]], columns=p.columns)
        with self.assertRaises(ValueError):
            q.backtest(p, t, "2020-01-02", cost_bps=-1)

    def test_24_risk_beta_identical_benchmark(self):
        p = self.data[[q.BENCHMARK]].copy()
        p["COPY"] = p[q.BENCHMARK]
        report = q.risk_snapshot(p, ["COPY"], q.BENCHMARK)
        self.assertAlmostEqual(report.loc["COPY", "Beta"], 1.)
        self.assertAlmostEqual(report.loc["COPY", "与基准相关系数"], 1.)

    def test_25_ic_nonoverlap_windows(self):
        summary, curves = q.factor_diagnostics(self.prices, {"momentum": self.factors["momentum"]}, q.BACKTEST_START, [21], 10)
        sample = curves[("momentum", 21)].dropna().iloc[::21]
        positions = self.prices.index.get_indexer(sample.index)
        self.assertTrue((np.diff(positions) >= 21).all())
        self.assertEqual(summary.loc[("momentum", 21), "非重叠样本数"], len(sample))

    def test_26_quantile_tail_not_filled(self):
        table = q.quantile_forward_returns(self.prices, self.factors["composite"], q.BACKTEST_START, 21)
        self.assertTrue(table.iloc[-22:].isna().all().all())
        self.assertFalse(table.iloc[:-22].isna().any().any())

    def test_27_full_workflow(self):
        d = q.run_demo("synthetic", plot=False, verbose=False)
        self.assertEqual(d["metrics"].shape, (6, 6))
        self.assertEqual(d["ic_summary"].shape, (12, 7))
        self.assertTrue(np.isfinite(d["metrics"].to_numpy()).all())
        for name, result in d["results"].items():
            expected = (1 + result["return"]).cumprod()
            np.testing.assert_allclose(result["nav"], expected, atol=1e-12)

    def test_28_cost_experiment_runs_on_cached_data(self):
        table = q.cost_sensitivity(self.prices, "reversal_ls", q.BACKTEST_START, 5, [0, 10, 25])
        self.assertEqual(table.shape, (3, 6))
        self.assertTrue(table["累计收益（%）"].is_monotonic_decreasing)


if __name__ == "__main__":
    unittest.main(verbosity=2)
