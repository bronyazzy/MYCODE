# BQuant 宏观量化培训代码包

主线：宏观 surprise → 公告反应 → 延迟入场 → 成本 → 时间样本外评价。

**全部自带数据和 Notebook 输出均为合成数据。没有真实 Bloomberg 行情，没有真实策略业绩，也没有下单功能。**

## 文件

- `BQuant_Macro_Training.ipynb`：自包含、中文分节说明、图表和已执行的演示输出。可以单独使用。
- `bquant_macro.py`：可导入或直接运行的核心函数，包括 BQL 日频适配器。
- `test_bquant_macro.py`：21 项离线回归测试。
- `tests.log`：测试运行记录。
- `demo_output/`：合成输入 CSV、逐事件审计、逐笔 P&L、汇总和滑点敏感性。
- `requirements.txt`：本地运行的基础依赖；不要为了此示例修改机构管理的 BQuant 环境。

## 启动

在 BQuant 中导入 Notebook 后，从上到下执行。默认不调用 BQL，不依赖真实数据。
Notebook 自包含，不要求同目录存在 `.py` 文件。

普通本地 Python：

```bash
python -m pip install -r requirements.txt
python bquant_macro.py --out demo_output
python -m unittest -v test_bquant_macro.py
```

在自己的 Notebook 中引用核心函数：

```python
from bquant_macro import Config, make_demo_data, backtest_events, event_study

events, quotes, specs = make_demo_data()
cfg = Config(threshold=1.0, execution_delay="60s", holding_period="30min")
result = backtest_events(events, quotes, specs, cfg)
print(result["summary"])
print(result["trades"].tail())
```

## 信号与执行约定

`surprise = first_actual - consensus`

`scaled_surprise = surprise / 历史 surprise 标准差`

标准差仅使用该指标此前已经可用的事件：先按 `actual_available_ts` 排序，再 `shift(1)` 和滚动计算。
不减历史均值，保留 surprise 方向。默认窗口 24 次，最少 12 次历史。

默认假设正 surprise 做空所选合约，负 surprise 做多；只有绝对标准化 surprise >= 1 才交易。
此方向只是示范假设，并非推荐或已经验证的经济规律。不同指标和品种应分别研究。

实际入场报价严格晚于 `actual_available_ts + execution_delay`。
退出目标为实际入场时间加持有期，再取严格晚于目标的首个报价。
报价匹配受 `quote_tolerance` 限制。默认分钟快照不支持精确秒级成交：实际入场晚于延迟门槛。

买入 = ask + 滑点；卖出 = bid - 滑点；每边收取每张合约手续费。
每次固定合约数，全局最多一个仓位。事件重叠则跳过后续入场并保留原因。

缺少入场报价可以不交易；已入场却缺少退出报价必须停止回测，不能删除未知亏损的交易。

## 真实数据契约

### events.csv

| 列 | 说明 |
|---|---|
| event_id | 唯一事件标识 |
| indicator | 指标标识；同一分组单位、统计口径、季调方式一致 |
| reference_period | 经济参考期，不用于代替发布时间 |
| release_ts | 实际发布时间，必须带时区 |
| actual_available_ts | 当时策略能够收到初值的时间，不早于公布时间 |
| first_actual | 首次公布值，不是最终修订值 |
| consensus | 公布前已归档的预期，与 actual 单位一致 |
| consensus_asof | 该预期的真实历史快照时间，严格早于公布 |
| contract | 公告前选定的具体交易合约 |
| contract_selected_ts | 选择该合约的时点，严格早于公布 |
| is_first_release | True；只做声明一致性检查，不能证明数据真的未经修订 |
| source | 数据来源、查询或版本的可追溯标识 |

时间字符串例：`2025-01-15T13:30:00Z`。这里只展示格式，不表示真实事件。
不能把今天的下载时间填入历史 available/asof，不能把今天下载的最终历史值标成当时初值。

### quotes.csv

`contract, ts, bid, ask, bid_size, ask_size`

必须是当时可观察的有效双边报价快照，报价量单位为合约数；不要把 OHLC close 当成交 bid/ask。
`ts` 必须带时区。同一合约同一时间不得重复；来源或序列号的冲突需在上游消歧。
模板不证明两侧报价的新鲜度或必然可成交，仍须核对数据源和市场状态。
价格须为十进制价格点；本模板只处理正价格。不要直接输入 32 分数报价字符串。

### specs.csv

`contract, point_value_usd, tick_size, currency`

`point_value_usd` = 每一整价格点、每张合约的美元金额；不是保证金金额，也不是每 tick 金额。
只接受 USD；其他币种需要单独加入时点汇率转换。
每个具体合约需一条规格，必须使用实际合约规格，不能照抄合成示例。

## BQL 接通

`bql_daily_levels()` 是按 Service / Request 模式编写的待现场验证适配器；**未连接你的 Bloomberg 环境实测**。
Notebook 的 `USE_BLOOMBERG=False` 默认为关闭。请讲师确认证券代码、PX_LAST 口径、查询语法、返回维度、账户权限和默认填充规则后再开启。

本代码**没有编造**经济初值、历史 consensus 或具体合约分钟 bid/ask 的 BQL 字段名。
应由讲师将授权数据源映射到上述三张表。
不要在外部环境盲目安装名字相同、来源不明的 `bql` 包。
真实数据的保存和分享需遵守数据授权和机构规则。

## 结果的正确读法

- `event_study` 的 announcement move：公告前到公告后的中间价变化，不是交易收益。
- `event_study` 的 post-entry move：延迟入场后中间价变化，尚未扣成本。
- `trades` 的 net_pnl_usd：按具体合约价格点金额计算、扣除双边价差/滑点/费用的模拟 P&L。
- `summary`：固定参数、时间分段的 train/test 结果；未做机器学习拟合或参数优化。
- `closed_trade_max_drawdown_usd`：仅按平仓 P&L 序列计算，不是逐日或持仓内最大回撤。
- 不输出年化 Sharpe：此引擎没有构造完整逐日盯市、保证金、资金占用和现金收益序列。
- 成本敏感性保持同一组成交时点及手数，只改变每边额外滑点，不是重新优化。

跨资产模块用价格百分比变化、收益率基点变化和曲线斜率；不把收益率 pct_change 当作债券收益。
PX_LAST 价格变化不包含所有分红、融资或换月影响，也不是总收益。
本地没有前向填充，不保证源数据没有填充；真实数据需核对日历、缺失机制和不同市场收盘时间。

## 测试范围和局限

21 项测试覆盖未来数据不影响过去结果、成交时序、成本恒等式、时区、历史预期时间、修订标识、异常价差、缺失成交、重叠持仓、币种、零波动、回撤起点及单位转换。
测试通过只说明所测实现行为符合设计，不证明策略有效，也不证明真实数据无偏。

此原型没有生产级保证金、融资、市场冲击、多档撮合、真实连续合约换月、多资产风险预算或自动下单。
不能把泛合约连续价格直接视为无成本可交易价格；本例每个事件使用公告前已选定且持有期间不切换的具体合约。

## 公开参考

Bloomberg BQuant 产品与授权数据访问说明：
https://professional.bloomberg.com/products/bloomberg-terminal/research/bquant/

pandas 官方 merge_asof（前向/后向配对、严格匹配、容忍区间）：
https://pandas.pydata.org/docs/reference/api/pandas.merge_asof.html

pandas 官方 Series.shift：
https://pandas.pydata.org/docs/reference/api/pandas.Series.shift.html

这些公开页面并不验证本 BQL 适配器的当前账户兼容性。
