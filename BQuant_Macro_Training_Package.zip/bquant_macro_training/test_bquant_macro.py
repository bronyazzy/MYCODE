"""离线回归测试: python -m unittest -v test_bquant_macro.py"""
import unittest
from dataclasses import replace

import numpy as np
import pandas as pd

from bquant_macro import (
    Config, backtest_events, build_signals, cost_sensitivity, cross_asset_changes,
    event_study, make_demo_data, trade_summary, validate_events,
)


class TestMacroTraining(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.events, cls.quotes, cls.specs = make_demo_data()
        cls.cfg = Config()
        cls.result = backtest_events(cls.events, cls.quotes, cls.specs, cls.cfg)

    def test_future_values_do_not_change_past_signals(self):
        changed = self.events.copy()
        changed.loc[60:, "first_actual"] += 100
        original = build_signals(self.events, self.cfg)
        revised = build_signals(changed, self.cfg)
        pd.testing.assert_frame_equal(original.iloc[:60], revised.iloc[:60])

    def test_future_prices_do_not_change_past_trades(self):
        prefix_events = self.events.iloc[:60]
        prefix_quotes = self.quotes[self.quotes["contract"].isin(prefix_events["contract"])]
        prefix = backtest_events(prefix_events, prefix_quotes, self.specs, self.cfg)["trades"]
        original = self.result["trades"]
        expected = original[original["event_id"].isin(prefix_events["event_id"])].reset_index(drop=True)
        pd.testing.assert_frame_equal(prefix, expected)

    def test_entry_and_exit_are_strictly_after_eligibility(self):
        t = self.result["trades"]
        self.assertGreater(len(t), 0)
        self.assertTrue((t["entry_ts"] > t["entry_ready_ts"]).all())
        self.assertTrue((t["exit_ts"] > t["exit_ready_ts"]).all())
        self.assertTrue((t["exit_ready_ts"] == t["entry_ts"] + pd.Timedelta(self.cfg.holding_period)).all())

    def test_cost_accounting_identity(self):
        t = self.result["trades"]
        np.testing.assert_allclose(t["gross_mid_pnl_usd"] - t["total_cost_usd"], t["net_pnl_usd"])
        np.testing.assert_allclose(
            t["spread_cost_usd"] + t["slippage_cost_usd"] + t["fee_cost_usd"], t["total_cost_usd"])

    def test_higher_fees_reduce_pnl_by_exact_amount(self):
        cfg = replace(self.cfg, fee_per_contract_side_usd=self.cfg.fee_per_contract_side_usd + 1)
        t = backtest_events(self.events, self.quotes, self.specs, cfg)["trades"]
        np.testing.assert_allclose(self.result["trades"]["net_pnl_usd"] - t["net_pnl_usd"], 2 * cfg.contracts)

    def test_naive_timestamps_rejected(self):
        e = self.events.copy()
        e["release_ts"] = e["release_ts"].dt.tz_localize(None)
        with self.assertRaises(ValueError):
            validate_events(e)

    def test_late_consensus_rejected(self):
        e = self.events.copy()
        e.loc[0, "consensus_asof"] = e.loc[0, "release_ts"]
        with self.assertRaises(ValueError):
            validate_events(e)

    def test_revised_actuals_rejected(self):
        e = self.events.copy()
        e.loc[0, "is_first_release"] = False
        with self.assertRaises(ValueError):
            validate_events(e)

    def test_invalid_spread_rejected(self):
        q = self.quotes.copy()
        q.loc[0, "bid"] = q.loc[0, "ask"] + 1
        with self.assertRaises(ValueError):
            backtest_events(self.events, q, self.specs, self.cfg)

    def test_missing_entry_is_audited(self):
        first = self.result["trades"].iloc[0]
        q = self.quotes[self.quotes["contract"] != first["contract"]]
        r = backtest_events(self.events, q, self.specs, self.cfg)
        a = r["audit"].set_index("event_id")
        self.assertEqual(a.loc[first["event_id"], "status"], "no_entry_quote")
        self.assertEqual(len(r["audit"]), len(self.events))

    def test_missing_exit_fails_instead_of_deleting_trade(self):
        first = self.result["trades"].iloc[0]
        remove = self.quotes["contract"].eq(first["contract"]) & self.quotes["ts"].gt(first["entry_ts"])
        with self.assertRaises(RuntimeError):
            backtest_events(self.events, self.quotes.loc[~remove], self.specs, self.cfg)

    def test_insufficient_exit_size_fails(self):
        first = self.result["trades"].iloc[0]
        q = self.quotes.copy()
        mask = q["contract"].eq(first["contract"]) & q["ts"].eq(first["exit_ts"])
        q.loc[mask, ["bid_size", "ask_size"]] = 0
        with self.assertRaises(RuntimeError):
            backtest_events(self.events, q, self.specs, self.cfg)

    def test_overlapping_event_not_double_counted(self):
        first_id = self.result["trades"].iloc[0]["event_id"]
        extra = self.events[self.events["event_id"].eq(first_id)].copy()
        extra["event_id"] = "OVERLAP_TEST"
        extra["release_ts"] += pd.Timedelta(seconds=1)
        extra["actual_available_ts"] += pd.Timedelta(seconds=1)
        extra["first_actual"] += 100
        e = pd.concat([self.events, extra], ignore_index=True)
        r = backtest_events(e, self.quotes, self.specs, self.cfg)
        status = r["audit"].set_index("event_id").loc["OVERLAP_TEST", "status"]
        self.assertEqual(status, "overlapping_position")

    def test_currency_conversion_not_silently_assumed(self):
        s = self.specs.copy()
        s.loc[0, "currency"] = "EUR"
        with self.assertRaises(ValueError):
            backtest_events(self.events, self.quotes, s, self.cfg)

    def test_zero_history_variance_means_no_trade(self):
        e = self.events.copy()
        e["first_actual"] = e["consensus"]
        r = backtest_events(e, self.quotes, self.specs, self.cfg)
        self.assertTrue(r["trades"].empty)
        self.assertEqual(r["summary"].loc["all", "trades"], 0)

    def test_drawdown_includes_first_loss(self):
        t = pd.DataFrame({"net_pnl_usd": [-100.0, 20.0], "total_cost_usd": [5.0, 5.0],
                          "sample": ["test", "test"], "exit_ts": pd.date_range("2025-01-01", periods=2)})
        self.assertEqual(trade_summary(t).loc["test", "closed_trade_max_drawdown_usd"], 100.0)

    def test_yields_use_basis_points_and_no_local_forward_fill(self):
        levels = pd.DataFrame({"P": [100.0, np.nan, 103.0], "Y": [4.0, 4.1, 4.2]},
                              index=pd.date_range("2025-01-01", periods=3))
        changes = cross_asset_changes(levels, ["P"], ["Y"])
        self.assertTrue(changes["P | price_change_pct"].isna().all())
        np.testing.assert_allclose(changes["Y | yield_change_bp"].iloc[1:], 10.0)

    def test_study_preserves_all_events(self):
        study = event_study(self.events, self.quotes, self.specs, self.cfg)
        self.assertEqual(len(study), len(self.events))
        self.assertTrue(study["study_status"].eq("ok").all())
        self.assertTrue((study["pre_release_quote_ts"] < study["release_ts"]).all())
        self.assertTrue((study["entry_quote_ts"] > study["entry_ready_ts"]).all())

    def test_extra_slippage_never_improves_test_pnl(self):
        table = cost_sensitivity(self.result["trades"])
        self.assertTrue((table["net_pnl_usd"].diff().dropna() <= 0).all())

    def test_daylight_saving_is_not_fixed_utc_hour(self):
        jan = self.events.iloc[0]["release_ts"]
        jul = self.events.iloc[6]["release_ts"]
        self.assertEqual(jan.hour, 13)
        self.assertEqual(jul.hour, 12)

    def test_invalid_configuration_rejected(self):
        with self.assertRaises(ValueError):
            Config(min_history=1)
        with self.assertRaises(ValueError):
            Config(execution_delay="-1s")


if __name__ == "__main__":
    unittest.main()
