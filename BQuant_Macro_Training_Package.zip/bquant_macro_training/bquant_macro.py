"""BQuant 宏观事件研究培训代码。

默认只运行合成数据；没有自动交易功能。BQL 适配器未连接 Bloomberg 实测。
宏观数据的 first_actual / consensus 必须来自真实的 point-in-time 来源；
列名及时间检查不能证明数据源本身不存在修订或未来信息。

依赖: numpy, pandas, matplotlib。Notebook 另需 Jupyter。
运行: python bquant_macro.py --out demo_output
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
import argparse
import json
import platform

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class Config:
    """教学参数，不代表优化结果或投资建议。"""
    lookback: int = 24                 # 过去 24 次同一指标的 surprise
    min_history: int = 12
    threshold: float = 1.0            # |surprise / past_std| >= 1 才交易
    direction: int = -1              # 假设：正向 surprise 对所选价格偏空
    contracts: int = 1               # 固定合约数，不是保证金收益率
    execution_delay: str = "60s"     # 从 actual_available_ts 开始计时
    holding_period: str = "30min"    # 从实际入场报价时间开始计时
    quote_tolerance: str = "65s"     # 禁止跨大缺口补配成交报价
    reaction_horizon: str = "30min"
    fee_per_contract_side_usd: float = 2.5
    slippage_ticks_per_side: float = 1.0
    split_ts: str = "2022-12-31T23:59:59Z"

    def __post_init__(self) -> None:
        if not (2 <= self.min_history <= self.lookback):
            raise ValueError("需要 2 <= min_history <= lookback。")
        if self.direction not in (-1, 1):
            raise ValueError("direction 必须为 -1 或 +1。")
        if not isinstance(self.contracts, int) or self.contracts <= 0:
            raise ValueError("contracts 必须为正整数。")
        for name in ("threshold", "fee_per_contract_side_usd", "slippage_ticks_per_side"):
            value = getattr(self, name)
            if not np.isfinite(value) or value < 0:
                raise ValueError(f"{name} 必须为非负有限数。")
        for name in ("execution_delay", "holding_period", "quote_tolerance", "reaction_horizon"):
            value = pd.Timedelta(getattr(self, name))
            if pd.isna(value) or value < pd.Timedelta(0):
                raise ValueError(f"{name} 必须为非负时间间隔。")
            if name != "execution_delay" and value == pd.Timedelta(0):
                raise ValueError(f"{name} 必须大于零。")
        _timestamp_utc(self.split_ts)


def _timestamp_utc(value) -> pd.Timestamp:
    ts = pd.Timestamp(value)
    if pd.isna(ts) or ts.tzinfo is None:
        raise ValueError(f"时间必须包含时区，不能默认把本地时间当作 UTC: {value!r}")
    return ts.tz_convert("UTC")


def _utc_column(series: pd.Series) -> pd.Series:
    # 显式拒绝无时区输入；对不同夏令时 offset 的字符串也适用。
    return pd.Series(
        pd.DatetimeIndex([_timestamp_utc(x) for x in series]),
        index=series.index,
    )


def _required(df: pd.DataFrame, columns: Iterable[str], name: str) -> None:
    missing = set(columns) - set(df.columns)
    if missing:
        raise ValueError(f"{name} 缺少列: {sorted(missing)}")
    if df.empty:
        raise ValueError(f"{name} 不能为空。")
    if df[list(columns)].isna().any().any():
        raise ValueError(f"{name} 的必需列不能包含缺失值。")


def validate_events(events: pd.DataFrame) -> pd.DataFrame:
    """一行一个事件；同一 indicator 必须使用相同单位、口径和季调方式。"""
    required = [
        "event_id", "indicator", "reference_period", "release_ts", "actual_available_ts",
        "first_actual", "consensus", "consensus_asof", "contract",
        "contract_selected_ts", "is_first_release", "source",
    ]
    _required(events, required, "events")
    e = events.copy()
    for name in ("release_ts", "actual_available_ts", "consensus_asof", "contract_selected_ts"):
        e[name] = _utc_column(e[name])
    for name in ("first_actual", "consensus"):
        e[name] = pd.to_numeric(e[name], errors="raise")
        if not np.isfinite(e[name]).all():
            raise ValueError(f"{name} 包含非有限值。")
    # 接受 CSV 的 true/false，但不使用 bool('False') 这种危险转换。
    first = e["is_first_release"].astype(str).str.strip().str.lower()
    if not first.eq("true").all():
        raise ValueError("所有 is_first_release 必须为 True；不能把修订值当初值。")
    e["is_first_release"] = True
    for name in ("event_id", "indicator", "contract", "source"):
        if e[name].astype(str).str.strip().eq("").any():
            raise ValueError(f"{name} 不能为空字符串。")
    if e["event_id"].duplicated().any():
        raise ValueError("event_id 必须唯一。")
    if e.duplicated(["indicator", "release_ts"]).any():
        raise ValueError("同一指标同一发布时间存在重复事件。")
    if e.duplicated(["indicator", "actual_available_ts"]).any():
        raise ValueError("同一指标的可用时间重复；需要先处理同时到达的数据批次。")
    if not (e["consensus_asof"] < e["release_ts"]).all():
        raise ValueError("consensus_asof 必须严格早于发布时间。")
    if not (e["actual_available_ts"] >= e["release_ts"]).all():
        raise ValueError("actual_available_ts 不得早于发布时间。")
    if not (e["contract_selected_ts"] < e["release_ts"]).all():
        raise ValueError("交易合约必须在事件公布前选定，不能事后按表现挑选。")
    return e.sort_values(["actual_available_ts", "event_id"]).reset_index(drop=True)


def validate_market(
    quotes: pd.DataFrame, specs: pd.DataFrame, contracts: Iterable[str]
) -> tuple[pd.DataFrame, pd.DataFrame]:
    _required(quotes, ["contract", "ts", "bid", "ask", "bid_size", "ask_size"], "quotes")
    _required(specs, ["contract", "point_value_usd", "tick_size", "currency"], "specs")
    q, s = quotes.copy(), specs.copy()
    q["ts"] = _utc_column(q["ts"])
    if q.duplicated(["contract", "ts"]).any():
        raise ValueError("同一合约同一时间存在多条报价，请先按来源或序列号消歧。")
    if s["contract"].duplicated().any():
        raise ValueError("每个合约只能有一条规格记录。")
    if not s["currency"].eq("USD").all():
        raise ValueError("本示例仅汇总美元 P&L；其他币种须另做时点汇率换算。")
    for name in ("bid", "ask", "bid_size", "ask_size"):
        q[name] = pd.to_numeric(q[name], errors="raise")
        if not np.isfinite(q[name]).all():
            raise ValueError(f"quotes.{name} 包含非有限值。")
    if (q[["bid", "ask"]] <= 0).any().any() or (q["bid"] > q["ask"]).any():
        raise ValueError("本模板要求正价格且 bid <= ask。")
    sizes = q[["bid_size", "ask_size"]]
    if (sizes < 0).any().any() or not np.equal(sizes, np.floor(sizes)).all().all():
        raise ValueError("报价量必须是非负整数，单位为合约数。")
    for name in ("point_value_usd", "tick_size"):
        s[name] = pd.to_numeric(s[name], errors="raise")
        if not np.isfinite(s[name]).all() or (s[name] <= 0).any():
            raise ValueError(f"specs.{name} 必须为正有限数。")
    needed = set(contracts)
    if not needed.issubset(set(s["contract"])):
        raise ValueError("部分事件的具体交易合约缺少规格。")
    # 不要求每个事件都有报价：缺少入场报价会记录为未交易，而不是填充。
    return q.sort_values("ts").reset_index(drop=True), s.set_index("contract")


def build_signals(events: pd.DataFrame, cfg: Config = Config()) -> pd.DataFrame:
    e = validate_events(events)
    e["surprise"] = e["first_actual"] - e["consensus"]
    # 数据已按 actual_available_ts 排序：只使用当时已经可用的历史 surprise。
    e["past_std"] = e.groupby("indicator", sort=False)["surprise"].transform(
        lambda x: x.shift(1).rolling(cfg.lookback, min_periods=cfg.min_history).std(ddof=1)
    )
    # 保留 actual-consensus 的符号；这里不减历史均值。
    e["scaled_surprise"] = e["surprise"] / e["past_std"].where(e["past_std"] > 1e-12)
    e["signal"] = 0
    active = e["scaled_surprise"].abs().ge(cfg.threshold) & e["scaled_surprise"].ne(0)
    e.loc[active, "signal"] = (
        cfg.direction * np.sign(e.loc[active, "scaled_surprise"])
    ).astype(int)
    e["entry_ready_ts"] = e["actual_available_ts"] + pd.Timedelta(cfg.execution_delay)
    return e


def _quote_at(
    q: pd.DataFrame, target: pd.Timestamp, tolerance: pd.Timedelta,
    direction: str = "forward", strict: bool = True,
) -> pd.Series | None:
    """前向配对用于模拟未来成交；后向配对用于观察公布前价格。"""
    if q.empty:
        return None
    query = pd.DataFrame({"target_ts": [target]})
    match = pd.merge_asof(
        query, q, left_on="target_ts", right_on="ts",
        direction=direction, tolerance=tolerance, allow_exact_matches=not strict,
    ).iloc[0]
    return None if pd.isna(match["ts"]) else match


def _mid(quote: pd.Series) -> float:
    return float((quote["bid"] + quote["ask"]) / 2)


def event_study(
    events: pd.DataFrame, quotes: pd.DataFrame, specs: pd.DataFrame,
    cfg: Config = Config(),
) -> pd.DataFrame:
    """价格反应研究，不是可成交策略收益；保留无法配对的事件并记录状态。"""
    e = build_signals(events, cfg)
    q, _ = validate_market(quotes, specs, e["contract"])
    groups = {k: v.sort_values("ts") for k, v in q.groupby("contract", sort=False)}
    tol = pd.Timedelta(cfg.quote_tolerance)
    split = _timestamp_utc(cfg.split_ts)
    rows = []
    for event in e.to_dict("records"):
        r = dict(event)
        cq = groups.get(event["contract"], q.iloc[:0])
        before = _quote_at(cq, event["release_ts"], tol, "backward", strict=True)
        after = _quote_at(cq, event["release_ts"] + pd.Timedelta(cfg.reaction_horizon),
                          tol, "forward", strict=False)
        entry = _quote_at(cq, event["entry_ready_ts"], tol, strict=True)
        later = None if entry is None else _quote_at(
            cq, entry["ts"] + pd.Timedelta(cfg.holding_period), tol, strict=True)
        r["study_status"] = "ok" if all(x is not None for x in (before, after, entry, later)) else "missing_quote"
        r["pre_release_quote_ts"] = pd.NaT if before is None else before["ts"]
        r["reaction_quote_ts"] = pd.NaT if after is None else after["ts"]
        r["entry_quote_ts"] = pd.NaT if entry is None else entry["ts"]
        r["post_entry_quote_ts"] = pd.NaT if later is None else later["ts"]
        r["announcement_move_points"] = np.nan if before is None or after is None else _mid(after) - _mid(before)
        r["post_entry_move_points"] = np.nan if entry is None or later is None else _mid(later) - _mid(entry)
        # 研究结果跨越分界线时，不放入任何单侧样本。
        end_ts = None if after is None or later is None else max(after["ts"], later["ts"])
        r["sample"] = "test" if event["release_ts"] > split else (
            "train" if end_ts is not None and end_ts <= split else "boundary_or_incomplete")
        rows.append(r)
    return pd.DataFrame(rows)


def trade_summary(trades: pd.DataFrame) -> pd.DataFrame:
    """按平仓序列汇总；不冒充逐日盯市，不计算年化 Sharpe。"""
    columns = ["sample", "trades", "net_pnl_usd", "avg_net_usd", "win_rate",
               "worst_trade_usd", "total_cost_usd", "profit_factor",
               "closed_trade_max_drawdown_usd"]
    rows = []
    for sample in ("all", "train", "test"):
        t = trades if sample == "all" else trades.loc[trades["sample"].eq(sample)]
        if t.empty:
            rows.append(dict(zip(columns, [sample, 0, 0.0, np.nan, np.nan,
                                           np.nan, 0.0, np.nan, 0.0])))
            continue
        pnl = t.sort_values("exit_ts")["net_pnl_usd"].to_numpy(dtype=float)
        cumulative = np.r_[0.0, pnl.cumsum()]  # 包含初始零点，首笔亏损也计入回撤。
        closed_dd = np.maximum.accumulate(cumulative) - cumulative
        losses = -pnl[pnl < 0].sum()
        rows.append({
            "sample": sample, "trades": len(t), "net_pnl_usd": pnl.sum(),
            "avg_net_usd": pnl.mean(), "win_rate": (pnl > 0).mean(),
            "worst_trade_usd": pnl.min(), "total_cost_usd": t["total_cost_usd"].sum(),
            "profit_factor": pnl[pnl > 0].sum() / losses if losses > 0 else np.nan,
            "closed_trade_max_drawdown_usd": closed_dd.max(),
        })
    return pd.DataFrame(rows, columns=columns).set_index("sample")


TRADE_COLUMNS = [
    "event_id", "indicator", "contract", "release_ts", "actual_available_ts",
    "consensus_asof", "surprise", "scaled_surprise", "signal", "contracts",
    "entry_ready_ts", "entry_ts", "exit_ready_ts", "exit_ts", "entry_bid", "entry_ask",
    "exit_bid", "exit_ask", "entry_exec", "exit_exec", "point_value_usd", "tick_size",
    "gross_mid_pnl_usd", "spread_cost_usd", "slippage_cost_usd", "fee_cost_usd",
    "total_cost_usd", "net_pnl_usd", "sample", "source",
]


def backtest_events(
    events: pd.DataFrame, quotes: pd.DataFrame, specs: pd.DataFrame,
    cfg: Config = Config(),
) -> dict[str, pd.DataFrame]:
    """固定手数、单仓位、线性美元合约的事件回测。

    缺少入场报价可以不交易；已入场而缺少退出报价则报错，不能删除亏损未知的交易。
    报价须为当时可观察的有效 bid/ask 快照，不能把分钟 OHLC close 伪装成可执行报价。
    不含保证金、融资、排队、冲击、多档撮合或动态换月。
    """
    e = build_signals(events, cfg)
    q, s = validate_market(quotes, specs, e["contract"])
    groups = {k: v.sort_values("ts") for k, v in q.groupby("contract", sort=False)}
    tol = pd.Timedelta(cfg.quote_tolerance)
    split = _timestamp_utc(cfg.split_ts)
    trades, audit = [], []
    last_exit = None
    for event in e.to_dict("records"):
        a = dict(event)
        if not np.isfinite(event["scaled_surprise"]):
            a["status"] = "warmup_or_zero_std"
        elif event["signal"] == 0:
            a["status"] = "below_threshold"
        else:
            cq = groups.get(event["contract"], q.iloc[:0])
            entry = _quote_at(cq, event["entry_ready_ts"], tol, strict=True)
            side = int(event["signal"])
            qty = cfg.contracts
            entry_size_field = "ask_size" if side == 1 else "bid_size"
            if entry is None:
                a["status"] = "no_entry_quote"
            elif last_exit is not None and entry["ts"] < last_exit:
                a["status"] = "overlapping_position"
            elif entry[entry_size_field] < qty:
                a["status"] = "insufficient_entry_size"
            else:
                exit_ready = entry["ts"] + pd.Timedelta(cfg.holding_period)
                exit_quote = _quote_at(cq, exit_ready, tol, strict=True)
                if exit_quote is None:
                    raise RuntimeError(
                        f"{event['event_id']}: 已模拟入场但缺少退出报价。"
                        "停止回测；请补齐行情或明确预先约定的退出规则，不能悄悄删除交易。")
                exit_size_field = "bid_size" if side == 1 else "ask_size"
                if exit_quote[exit_size_field] < qty:
                    raise RuntimeError(f"{event['event_id']}: 退出报价量不足；本示例不模拟部分成交。")
                spec = s.loc[event["contract"]]
                pv, tick = float(spec["point_value_usd"]), float(spec["tick_size"])
                slip = cfg.slippage_ticks_per_side * tick
                entry_exec = float(entry["ask"] + slip if side == 1 else entry["bid"] - slip)
                exit_exec = float(exit_quote["bid"] - slip if side == 1 else exit_quote["ask"] + slip)
                gross = side * qty * pv * (_mid(exit_quote) - _mid(entry))
                spread = qty * pv * (
                    (entry["ask"] - entry["bid"]) / 2 +
                    (exit_quote["ask"] - exit_quote["bid"]) / 2)
                slip_cost = 2 * qty * pv * slip
                fees = 2 * qty * cfg.fee_per_contract_side_usd
                costs = spread + slip_cost + fees
                net = side * qty * pv * (exit_exec - entry_exec) - fees
                if not np.isclose(net, gross - costs, rtol=1e-10, atol=1e-8):
                    raise AssertionError("盈亏与成本分解不一致。")
                sample = "test" if entry["ts"] > split else (
                    "train" if exit_quote["ts"] <= split else "boundary")
                t = {k: event[k] for k in (
                    "event_id", "indicator", "contract", "release_ts", "actual_available_ts",
                    "consensus_asof", "surprise", "scaled_surprise", "signal", "entry_ready_ts", "source")}
                t.update({
                    "contracts": qty, "entry_ts": entry["ts"], "exit_ready_ts": exit_ready,
                    "exit_ts": exit_quote["ts"], "entry_bid": entry["bid"], "entry_ask": entry["ask"],
                    "exit_bid": exit_quote["bid"], "exit_ask": exit_quote["ask"],
                    "entry_exec": entry_exec, "exit_exec": exit_exec,
                    "point_value_usd": pv, "tick_size": tick, "gross_mid_pnl_usd": gross,
                    "spread_cost_usd": spread, "slippage_cost_usd": slip_cost,
                    "fee_cost_usd": fees, "total_cost_usd": costs, "net_pnl_usd": net,
                    "sample": sample,
                })
                trades.append(t)
                last_exit = exit_quote["ts"]
                a["status"] = "traded"
                a["entry_ts"], a["exit_ts"] = entry["ts"], exit_quote["ts"]
        audit.append(a)
    trade_df = pd.DataFrame(trades, columns=TRADE_COLUMNS)
    return {"trades": trade_df, "audit": pd.DataFrame(audit), "summary": trade_summary(trade_df)}


def cost_sensitivity(
    trades: pd.DataFrame, extra_ticks: Iterable[float] = (0, 0.5, 1, 2)
) -> pd.DataFrame:
    """固定成交时点和手数下，每边额外滑点的会计敏感性；不是重新优化策略。"""
    rows = []
    for extra in extra_ticks:
        if not np.isfinite(extra) or extra < 0:
            raise ValueError("额外滑点必须为非负有限数。")
        t = trades.copy()
        additional = 2 * extra * t["contracts"] * t["tick_size"] * t["point_value_usd"]
        t["total_cost_usd"] += additional
        t["net_pnl_usd"] -= additional
        row = trade_summary(t).loc["test"].to_dict()
        row["extra_ticks_per_side"] = extra
        rows.append(row)
    return pd.DataFrame(rows).set_index("extra_ticks_per_side")


def bql_daily_levels(tickers: list[str], start: str, end: str) -> pd.DataFrame:
    """BQuant 内的 BQL 取数模板，未连接 Bloomberg 实测。

    仅用于 PX_LAST 日频水平研究，不代表总收益、可成交报价或宏观历史初值。
    字段/参数/返回结构/证券代码/填充默认值请由培训讲师在当前环境核对。
    不在外部环境 pip install 名字相同但来源不明的 bql 包。
    """
    if not tickers or len(set(tickers)) != len(tickers):
        raise ValueError("tickers 必须为非空且无重复的列表。")
    if pd.Timestamp(start) > pd.Timestamp(end):
        raise ValueError("start 必须早于 end。")
    try:
        import bql  # Bloomberg BQuant 环境提供的 SDK
    except ImportError as exc:
        raise RuntimeError("请在具备授权的 BQuant 环境运行 BQL 单元；本地可先运行合成数据。") from exc
    try:
        bq = bql.Service()
        item = bq.data.px_last(dates=bq.func.range(start, end))
        response = bq.execute(bql.Request(tickers, {"PX_LAST": item}))
        raw = response[0].df().reset_index()
    except Exception as exc:
        raise RuntimeError("BQL 请求失败；请核对环境、权限、证券代码、日期范围与 SDK 语法。") from exc
    required = {"ID", "DATE", "PX_LAST"}
    if not required.issubset(raw.columns):
        raise ValueError(f"BQL 返回结构需要现场适配，实际列为: {raw.columns.tolist()}")
    raw["DATE"] = pd.to_datetime(raw["DATE"], errors="raise")
    raw["PX_LAST"] = pd.to_numeric(raw["PX_LAST"], errors="raise")
    if raw.duplicated(["ID", "DATE"]).any():
        raise ValueError("同一 ID/DATE 存在多行；先检查币种、来源或其他返回维度。")
    levels = raw.pivot(index="DATE", columns="ID", values="PX_LAST").sort_index()
    absent = set(tickers) - set(levels.columns)
    if absent:
        raise ValueError(f"这些代码没有返回数据: {sorted(absent)}")
    return levels.reindex(columns=tickers)


def cross_asset_changes(
    levels: pd.DataFrame, price_columns: list[str], yield_percent_columns: list[str],
) -> pd.DataFrame:
    """价格列输出百分比变化；以百分数报价的收益率列输出基点变化。

    例：4.00 -> 4.10 输出 +10 bp，而不是 +2.5% 的“债券收益”。
    本函数不填充缺失值；须另外核对 Bloomberg 源数据的日历和填充默认值。
    按观察行计算变化；不保证不同市场收盘同时，也不声称具备因果关系。
    """
    selected = price_columns + yield_percent_columns
    if not selected or len(set(selected)) != len(selected):
        raise ValueError("列选择必须非空、互不重叠且无重复。")
    if not set(selected).issubset(levels.columns):
        raise ValueError("部分选择的列不存在。")
    if not isinstance(levels.index, pd.DatetimeIndex) or not levels.index.is_monotonic_increasing:
        raise ValueError("levels 必须以递增 DatetimeIndex 索引。")
    if levels.index.has_duplicates:
        raise ValueError("levels 日期不能重复。")
    data = levels[selected].apply(pd.to_numeric, errors="raise")
    if np.isinf(data.to_numpy(dtype=float)).any():
        raise ValueError("levels 不能包含无穷值。")
    if price_columns and (data[price_columns] <= 0).any().any():
        raise ValueError("本价格变化示例要求正价格。")
    output = {}
    for col in price_columns:
        output[col + " | price_change_pct"] = data[col].pct_change(fill_method=None) * 100
    for col in yield_percent_columns:
        output[col + " | yield_change_bp"] = data[col].diff() * 100
    return pd.DataFrame(output, index=levels.index)


def make_demo_data(seed: int = 7, n_events: int = 96) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """所有数字、日历、合约名和报价均为合成；没有植入可预测的入场后 alpha。"""
    if n_events < 24:
        raise ValueError("示例至少需要 24 个事件。")
    rng = np.random.default_rng(seed)
    events, quotes, specs = [], [], []
    for i, month in enumerate(pd.date_range("2018-01-01", periods=n_events, freq="MS")):
        # 任意教学日历，并非真实经济发布日。纽约本地时间会正确转换夏令时。
        local = (month + pd.Timedelta(days=14, hours=8, minutes=30)).tz_localize("America/New_York")
        release = local.tz_convert("UTC")
        contract = f"SYNTH_RATE_{month:%Y%m}"
        consensus = float(0.2 + rng.normal(0, 0.04))
        surprise = float(rng.normal(0, 0.12))
        events.append({
            "event_id": f"DEMO_{i:03d}", "indicator": "SYNTH_CPI_MOM",
            "reference_period": str(month.to_period("M") - 1), "release_ts": release,
            "actual_available_ts": release + pd.Timedelta(seconds=2),
            "first_actual": consensus + surprise, "consensus": consensus,
            "consensus_asof": release - pd.Timedelta(minutes=5), "contract": contract,
            "contract_selected_ts": release - pd.Timedelta(days=1),
            "is_first_release": True, "source": "SYNTHETIC_NOT_BLOOMBERG",
        })
        tick, point_value = 1 / 64, 1000.0  # 仅为教学假设；真实合约须用实际规格。
        specs.append({"contract": contract, "tick_size": tick,
                      "point_value_usd": point_value, "currency": "USD"})
        times = pd.date_range(release - pd.Timedelta(minutes=5),
                              release + pd.Timedelta(minutes=90), freq="1min")
        walk = rng.normal(0, 0.018, len(times)).cumsum()
        # 人为设置公告跳跃；交易只能在跳跃后入场，之后增量独立随机。
        jump = np.where(times >= release, -1.1 * surprise, 0.0)
        mid = 110.0 + walk + jump
        bid = np.floor((mid - tick / 2) / tick) * tick
        quotes.append(pd.DataFrame({
            "contract": contract, "ts": times, "bid": bid, "ask": bid + 2 * tick,
            "bid_size": rng.integers(5, 30, len(times)),
            "ask_size": rng.integers(5, 30, len(times)),
        }))
    return pd.DataFrame(events), pd.concat(quotes, ignore_index=True), pd.DataFrame(specs)


def make_demo_levels(seed: int = 31) -> pd.DataFrame:
    """用于跨资产图表的合成日频水平，非 Bloomberg 价格。"""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2021-01-01", "2025-12-31")
    shock = rng.normal(size=(len(dates), 4))
    return pd.DataFrame({
        "SYNTH_EQUITY": 100 * np.exp(np.cumsum(0.0001 + 0.01 * shock[:, 0])),
        "SYNTH_FX": np.exp(np.cumsum(0.004 * shock[:, 1])),
        "SYNTH_2Y_YIELD": 3.0 + np.cumsum(0.02 * shock[:, 2]),
        "SYNTH_10Y_YIELD": 3.5 + np.cumsum(0.015 * shock[:, 2] + 0.01 * shock[:, 3]),
    }, index=dates)


def run_demo(out_dir: str = "demo_output") -> dict[str, pd.DataFrame]:
    """本地或 Notebook 中运行；仅写出合成数据和演示结果。"""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    e, q, s = make_demo_data()
    result = backtest_events(e, q, s)
    result["event_study"] = event_study(e, q, s)
    result["cost_sensitivity"] = cost_sensitivity(result["trades"])
    for name, df in {"demo_events": e, "demo_quotes": q, "demo_specs": s, **result}.items():
        df.to_csv(out / f"{name}.csv", index=name in ("summary", "cost_sensitivity"))
    versions = {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
                "data": "SYNTHETIC_NOT_BLOOMBERG", "bql_live_tested": False}
    (out / "environment.json").write_text(json.dumps(versions, indent=2), encoding="utf-8")
    print("SYNTHETIC DATA ONLY — NOT A STRATEGY PERFORMANCE CLAIM")
    print(result["summary"].round(3).to_string())
    print("\nEvent audit:")
    print(result["audit"]["status"].value_counts().to_string())
    print(f"\nWritten to: {out.resolve()}")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="BQuant 宏观事件研究：合成数据教学演示")
    parser.add_argument("--out", default="demo_output", help="合成数据和结果输出目录")
    args = parser.parse_args()
    run_demo(args.out)
