"""纯合成数据单元测试；不需要 bql，不验证 Bloomberg 服务或市场数据。"""
import unittest
from dataclasses import replace
import numpy as np
import pandas as pd
import bqnt_quant_training as q


class QuantTrainingTests(unittest.TestCase):
    def setUp(self):
        self.cfg = q.Config()
        dates = pd.bdate_range(self.cfg.data_start, self.cfg.data_end)
        rng = np.random.default_rng(101)
        r = rng.normal(0.0002, 0.008, size=(len(dates), 3))
        self.prices = pd.DataFrame(
            100.0 * np.cumprod(1.0 + r, axis=0),
            index=dates, columns=list(self.cfg.tickers)
        )
        self.volumes = pd.DataFrame(
            1000.0, index=dates, columns=list(self.cfg.tickers)
        )

    def test_initial_loss_counts_as_drawdown(self):
        stats = q.performance_stats(pd.DataFrame({'x': [-0.1, 0.1]}))
        self.assertAlmostEqual(stats.loc['x', 'Max drawdown'], -0.1)
        self.assertAlmostEqual(stats.loc['x', 'Cumulative return'], -0.01)

    def test_annualized_compound_return(self):
        stats = q.performance_stats(pd.DataFrame({'x': [0.001] * 252}))
        self.assertAlmostEqual(stats.loc['x', 'Annualized return'], 1.001**252 - 1)

    def test_sharpe_uses_daily_excess_returns(self):
        r = pd.DataFrame({'x': [0.01, -0.02, 0.03, 0.001]})
        rf = 0.04
        expected = ((r.x - ((1 + rf)**(1/252) - 1)).mean()
                    / r.x.std(ddof=1) * np.sqrt(252))
        self.assertAlmostEqual(q.performance_stats(r, annual_rf=rf).loc['x', 'Sharpe'], expected)

    def test_constant_series_sharpe_is_nan(self):
        stats = q.performance_stats(pd.DataFrame({'x': [0.0, 0.0, 0.0]}))
        self.assertTrue(np.isnan(stats.loc['x', 'Sharpe']))

    def test_missing_returns_raise(self):
        with self.assertRaises(ValueError):
            q.performance_stats(pd.DataFrame({'x': [0.1, np.nan]}))

    def test_bql_index_reshape_and_case_mapping(self):
        raw = pd.DataFrame({'ID': ['SPY US EQUITY', 'SPY US EQUITY'],
                            'DATE': ['2023-01-03', '2023-01-04'],
                            'PX': [100, 101], 'CURRENCY': ['USD', 'USD']}).set_index('ID')
        out = q.bql_frame_to_wide(raw, 'PX', ('SPY US Equity',))
        self.assertEqual(out.shape, (2, 1))
        self.assertEqual(out.iloc[1, 0], 101)

    def test_duplicate_bql_rows_raise(self):
        raw = pd.DataFrame({'ID': ['SPY US Equity']*2, 'DATE': ['2023-01-03']*2,
                            'PX': [100, 101]})
        with self.assertRaises(ValueError):
            q.bql_frame_to_wide(raw, 'PX', ('SPY US Equity',))

    def test_absent_security_raises(self):
        raw = pd.DataFrame({'ID': ['SPY US Equity'], 'DATE': ['2023-01-03'], 'PX': [100]})
        with self.assertRaises(ValueError):
            q.bql_frame_to_wide(raw, 'PX', self.cfg.tickers)

    def test_currency_mismatch_raises(self):
        raw = pd.DataFrame({'ID': ['SPY US Equity'], 'DATE': ['2023-01-03'],
                            'PX': [100], 'CURRENCY': ['EUR']})
        with self.assertRaises(ValueError):
            q.bql_frame_to_wide(raw, 'PX', ('SPY US Equity',))

    def test_zero_volume_dates_are_excluded(self):
        volume = self.volumes.copy()
        volume.iloc[10] = 0.0
        out, diagnostic = q.prepare_prices(self.prices, volume, self.cfg)
        self.assertEqual(len(out), len(self.prices)-1)
        self.assertEqual(int(diagnostic['Missing prices'].sum()), 0)

    def test_missing_price_does_not_get_filled(self):
        px = self.prices.copy()
        px.iloc[400, 1] = np.nan
        with self.assertRaises(ValueError):
            q.prepare_prices(px, self.volumes, self.cfg)

    def test_two_row_lag_and_initial_cash(self):
        bt, log = q.run_sma_backtest(self.prices, self.cfg)
        px = self.prices[self.cfg.strategy_ticker]
        signal = (px > px.rolling(self.cfg.sma_days).mean()).astype(float)
        expected = signal.shift(2).reindex(log.index)
        np.testing.assert_allclose(log['Held during day'].iloc[1:], expected.iloc[1:])
        self.assertEqual(log['Held during day'].iloc[0], 0.0)
        self.assertEqual(log['Target after close'].iloc[-1], 0.0)
        self.assertEqual(bt.isna().sum().sum(), 0)

    def test_buy_hold_fee_timing_and_final_liquidation(self):
        bt, log = q.run_sma_backtest(self.prices, self.cfg)
        px = self.prices[self.cfg.strategy_ticker].reindex(bt.index)
        c = self.cfg.cost_bps / 10000
        expected = px.iloc[-1] / px.iloc[0] * (1-c)**2
        actual = (1 + bt['Buy & hold (net)']).prod()
        self.assertAlmostEqual(actual, expected, places=12)
        self.assertAlmostEqual(log['Buy-hold cost fraction'].iloc[-1], c)
        self.assertEqual(log['Buy-hold turnover'].sum(), 2.0)

    def test_future_price_change_cannot_change_past_positions(self):
        _, old = q.run_sma_backtest(self.prices, self.cfg)
        changed = self.prices.copy()
        cutoff = pd.Timestamp('2024-05-01')
        changed.loc[changed.index >= cutoff, self.cfg.strategy_ticker] *= 1.3
        _, new = q.run_sma_backtest(changed, self.cfg)
        pd.testing.assert_frame_equal(old.loc[old.index < cutoff], new.loc[new.index < cutoff])

    def test_costs_reduce_terminal_wealth_for_same_trades(self):
        free, _ = q.run_sma_backtest(self.prices, replace(self.cfg, cost_bps=0.0))
        paid, _ = q.run_sma_backtest(self.prices, self.cfg)
        self.assertTrue(((1+paid).prod() <= (1+free).prod() + 1e-12).all())

    def test_complete_analysis_and_benchmark_beta(self):
        result = q.analyze_prices(self.prices, self.cfg)
        self.assertEqual(result['summary'].shape[0], 3)
        self.assertEqual(result['correlation'].shape, (3, 3))
        self.assertAlmostEqual(result['summary'].loc[self.cfg.benchmark, 'Beta vs benchmark'], 1.0)
        self.assertEqual(result['factor_snapshot'].shape, (3, 4))
        self.assertEqual(result['backtest_summary'].shape[0], 2)

    def test_future_rows_excluded_by_config(self):
        original = q.analyze_prices(self.prices, self.cfg)
        future = pd.DataFrame(999.0, index=pd.bdate_range('2026-01-01', '2026-02-01'),
                              columns=self.prices.columns)
        extended = q.analyze_prices(pd.concat([self.prices, future]), self.cfg)
        pd.testing.assert_frame_equal(original['summary'], extended['summary'])
        pd.testing.assert_frame_equal(original['factor_snapshot'], extended['factor_snapshot'])

    def test_insufficient_warmup_raises(self):
        short_cfg = replace(self.cfg, data_start='2022-12-01')
        with self.assertRaises(ValueError):
            q.prepare_prices(self.prices, self.volumes, short_cfg)


if __name__ == '__main__':
    unittest.main(verbosity=2)
