# -*- coding: utf-8 -*-
"""BQNT 量化分析培训示例：BQL 取数、风险指标、动量快照和均线回测。

使用：在已授权的 Bloomberg BQuant Python 环境运行本文件，或使用配套 Notebook。
只依赖 numpy、pandas、matplotlib，以及 Bloomberg 环境提供的 bql。
不下单、不访问外部网站、不自动导出 Bloomberg 数据。

重要：所有业绩均基于 PX_LAST 返回序列。本示例未验证分红/复权设置，
因此不把结果声明为含分红总回报，也不作为可交易策略的业绩证明。
当前编写环境没有 Bloomberg 会话；BQL 连接与字段参数须在培训环境验证。
"""

# %% 1. 导入与参数
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


@dataclass(frozen=True)
class Config:
    # 同市场、同币种的教学样本；不是推荐名单。
    tickers: Tuple[str, ...] = (
        "SPY US Equity", "QQQ US Equity", "IWM US Equity"
    )
    benchmark: str = "SPY US Equity"
    strategy_ticker: str = "SPY US Equity"
    data_start: str = "2022-01-01"       # 额外历史用于均线预热
    evaluation_start: str = "2023-01-01"
    data_end: str = "2025-12-31"         # 固定已结束的历史区间，便于课堂复现
    sma_days: int = 60
    periods_per_year: int = 252          # 年化约定，不是实际日历天数
    annual_rf: float = 0.0              # 教学假设，不是当前市场利率
    annual_cash_return: float = 0.0     # 教学现金收益假设，独立于 Sharpe 的 rf
    cost_bps: float = 5.0               # 每次全仓切换按交易前净值扣费

    def validate(self) -> None:
        keys = [x.strip().upper() for x in self.tickers]
        if not keys or len(set(keys)) != len(keys):
            raise ValueError("tickers 不得为空或包含重复代码。")
        if self.benchmark not in self.tickers:
            raise ValueError("benchmark 必须包含在 tickers 中。")
        if self.strategy_ticker not in self.tickers:
            raise ValueError("strategy_ticker 必须包含在 tickers 中。")
        if not (pd.Timestamp(self.data_start) < pd.Timestamp(self.evaluation_start)
                < pd.Timestamp(self.data_end)):
            raise ValueError("需要 data_start < evaluation_start < data_end。")
        if self.sma_days < 2 or self.periods_per_year <= 0:
            raise ValueError("均线窗口至少为 2，年化期数必须为正。")
        if not 0 <= self.cost_bps < 10000:
            raise ValueError("cost_bps 必须在 [0, 10000) 之间。")
        if min(self.annual_rf, self.annual_cash_return) <= -1:
            raise ValueError("年化利率必须大于 -100%。")
        if not np.isfinite([self.cost_bps, self.annual_rf,
                            self.annual_cash_return]).all():
            raise ValueError("费率和利率必须为有限数值。")


# %% 2. BQL 返回表规范化与数据质量检查

def bql_frame_to_wide(raw: pd.DataFrame, value_column: str,
                      tickers: Tuple[str, ...]) -> pd.DataFrame:
    """将单个 BQL item.df() 转为 DATE × ID；不静默聚合重复记录。"""
    frame = raw.copy()
    if not {"ID", "DATE"}.issubset(frame.columns):
        frame = frame.reset_index()
    required = {"ID", "DATE", value_column}
    if not required.issubset(frame.columns):
        raise ValueError(
            "BQL 返回结构不符合预期；需要 %s，实际为 %s。请检查 response[i].df()。"
            % (sorted(required), list(frame.columns))
        )
    if frame["ID"].isna().any() or frame["DATE"].isna().any():
        raise ValueError("BQL 返回空 ID 或空 DATE。")
    frame["DATE"] = pd.to_datetime(frame["DATE"], errors="raise")
    if frame["DATE"].dt.tz is not None:
        frame["DATE"] = frame["DATE"].dt.tz_localize(None)
    frame["DATE"] = frame["DATE"].dt.normalize()
    id_map = {x.strip().upper(): x for x in tickers}
    normalized = frame["ID"].astype(str).str.strip().str.upper()
    unknown = sorted(set(normalized) - set(id_map))
    if unknown:
        raise ValueError("返回了未预期的 ID，请核对证券映射：%s" % unknown)
    frame["ID"] = normalized.map(id_map)
    frame[value_column] = pd.to_numeric(frame[value_column], errors="raise")
    if frame.duplicated(["DATE", "ID"]).any():
        raise ValueError("同一 ID/DATE 有多条记录；请确认币种、来源或其他维度，勿直接取均值。")
    if value_column == "PX" and "CURRENCY" in frame.columns:
        currencies = set(frame["CURRENCY"].dropna().astype(str).str.upper())
        if currencies != {"USD"}:
            raise ValueError("本例要求 USD 口径，实际 CURRENCY=%s。" % currencies)
    wide = frame.pivot(index="DATE", columns="ID", values=value_column).sort_index()
    absent = [ticker for ticker in tickers if ticker not in wide.columns]
    if absent:
        raise ValueError("以下证券未返回数据，请检查代码或权限：%s" % absent)
    return wide.reindex(columns=list(tickers))


def prepare_prices(price_wide: pd.DataFrame, volume_wide: pd.DataFrame,
                   cfg: Config) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """以基准有正成交量的工作日作教学日历；任何样本价格缺口都报错。"""
    cfg.validate()
    if cfg.benchmark not in volume_wide:
        raise ValueError("缺少基准成交量，无法构造教学交易日历。")
    volume = volume_wide[cfg.benchmark].sort_index()
    valid = ((volume > 0) & (volume.index.dayofweek < 5)
             & (volume.index >= pd.Timestamp(cfg.data_start))
             & (volume.index <= pd.Timestamp(cfg.data_end)))
    sessions = volume.index[valid]
    if sessions.empty:
        raise ValueError("未找到基准成交日；请核对 PX_VOLUME、权限和日期参数。")
    prices = price_wide.reindex(index=sessions, columns=list(cfg.tickers)).copy()
    diagnostics = pd.DataFrame({
        "Observed sessions": len(sessions),
        "Available prices": prices.notna().sum(),
        "Missing prices": prices.isna().sum(),
    })
    if prices.isna().any().any():
        bad = prices.isna().sum()
        raise ValueError("基准成交日存在价格缺口，不填充、不跨缺口计算日收益：%s"
                         % bad[bad > 0].to_dict())
    if not np.isfinite(prices.to_numpy(dtype=float)).all() or (prices <= 0).any().any():
        raise ValueError("价格包含非正值或无穷值，请核对原始数据。")
    n_warmup = int((prices.index < pd.Timestamp(cfg.evaluation_start)).sum())
    if n_warmup < cfg.sma_days + 1:
        raise ValueError("预热历史不足：请提前 data_start 或缩短 sma_days。")
    n_eval = int((prices.index >= pd.Timestamp(cfg.evaluation_start)).sum())
    if n_eval < 2:
        raise ValueError("评估区间不足两个观测日。")
    return prices, diagnostics


def load_bloomberg_prices(cfg: Config) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """在 Bloomberg BQuant 内执行；故障时不回退到虚构数据或第三方行情。"""
    cfg.validate()
    try:
        import bql
    except ImportError as exc:
        raise RuntimeError(
            "缺少 Bloomberg bql 模块。请在已授权的 BQuant Python 环境运行，"
            "并由培训师核对 kernel；不要仅按模块名安装未知同名包。"
        ) from exc
    try:
        bq = bql.Service()
        dates = bq.func.range(cfg.data_start, cfg.data_end)
        request = bql.Request(list(cfg.tickers), {
            "PX": bq.data.px_last(dates=dates, currency="USD", fill="NA"),
            "VOL": bq.data.px_volume(dates=dates, fill="NA"),
        })
        response = bq.execute(request)
        # 用别名识别返回项，避免依赖 response 的项顺序。
        items = {item.name: item.df() for item in response}
    except Exception as exc:
        raise RuntimeError(
            "BQL 查询失败。请先用一个证券和一个月日期测试，"
            "再核对权限、PX_LAST/PX_VOLUME 与 dates/currency/fill 参数。"
            "原始错误保留在异常链中。"
        ) from exc
    if not {"PX", "VOL"}.issubset(items):
        raise ValueError("返回项别名不符：%s；请检查 response。" % list(items))
    px = bql_frame_to_wide(items["PX"], "PX", cfg.tickers)
    vol = bql_frame_to_wide(items["VOL"], "VOL", cfg.tickers)
    return prepare_prices(px, vol, cfg)


# %% 3. 收益与风险指标

def performance_stats(returns: pd.DataFrame, periods_per_year: int = 252,
                      annual_rf: float = 0.0) -> pd.DataFrame:
    """收益输入为小数。年化复合变化按观测期数计算，不是日历日 CAGR。"""
    r = returns.astype(float)
    if r.empty or len(r) < 2 or r.isna().any().any():
        raise ValueError("收益表需要至少两行，且不得含缺失值。")
    if not np.isfinite(r.to_numpy()).all() or (r <= -1).any().any():
        raise ValueError("收益必须有限且大于 -100%。")
    if periods_per_year <= 0 or not np.isfinite(annual_rf) or annual_rf <= -1:
        raise ValueError("请检查年化期数和无风险利率。")
    wealth = (1.0 + r).cumprod()
    # 初始净值为 1：即使首日下跌，也必须计入回撤。
    peak = wealth.cummax().clip(lower=1.0)
    drawdown = wealth / peak - 1.0
    daily_rf = (1.0 + annual_rf) ** (1.0 / periods_per_year) - 1.0
    excess = r - daily_rf
    excess_std = excess.std(ddof=1)
    sharpe = (excess.mean() / excess_std.where(excess_std > 1e-12)
              * np.sqrt(periods_per_year))
    return pd.DataFrame({
        "Cumulative return": wealth.iloc[-1] - 1.0,
        "Annualized return": wealth.iloc[-1] ** (periods_per_year / len(r)) - 1.0,
        "Annualized volatility": r.std(ddof=1) * np.sqrt(periods_per_year),
        "Sharpe": sharpe,
        "Max drawdown": drawdown.min(),
        "Observations": len(r),
    })


def factor_snapshot(prices: pd.DataFrame, periods_per_year: int = 252) -> pd.DataFrame:
    """样本末日的描述性动量/波动快照；未用作回测选样或事后择优。"""
    if len(prices) < 127:
        raise ValueError("21/63/126 日动量至少需要 127 个价格观测。")
    r = prices.pct_change(fill_method=None)
    return pd.DataFrame({
        "Momentum 21D": prices.iloc[-1] / prices.iloc[-22] - 1.0,
        "Momentum 63D": prices.iloc[-1] / prices.iloc[-64] - 1.0,
        "Momentum 126D": prices.iloc[-1] / prices.iloc[-127] - 1.0,
        "Volatility 63D (ann.)": r.tail(63).std(ddof=1) * np.sqrt(periods_per_year),
    })


# %% 4. 可审计的均线回测（只做多/现金，无杠杆）

def run_sma_backtest(prices: pd.DataFrame, cfg: Config
                     ) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """t-1 日收盘信号 -> t 日收盘调仓 -> t+1 日开始享有新仓位收益。

    评估首日开始时为空仓；不会偷偷继承预热期持仓。
    交易费是本例定义的“每次全仓切换占交易前净值的 cost_bps”。
    期末强制平仓并扣费；买入持有比较组合使用相同进出和费用规则。
    """
    cfg.validate()
    px = prices[cfg.strategy_ticker]
    if px.isna().any() or (px <= 0).any() or not np.isfinite(px).all():
        raise ValueError("回测价格存在缺失或非法值。")
    if not px.index.is_monotonic_increasing or px.index.has_duplicates:
        raise ValueError("价格日期必须严格递增且不重复。")
    ma = px.rolling(cfg.sma_days, min_periods=cfg.sma_days).mean()
    signal = (px > ma).astype(float).where(ma.notna())
    close_target = signal.shift(1)  # 今天收盘仅执行昨天已经知道的信号
    dates = px.index[(px.index >= pd.Timestamp(cfg.evaluation_start))
                     & (px.index <= pd.Timestamp(cfg.data_end))]
    if len(dates) < 2:
        raise ValueError("回测至少需要两个评估日。")
    if close_target.reindex(dates).isna().any():
        raise ValueError("均线或信号缺少预热数据。")
    asset_return = px.pct_change(fill_method=None).reindex(dates)
    if asset_return.isna().any():
        raise ValueError("评估区间需要前一交易日价格，不得填补缺失收益。")
    target = close_target.reindex(dates).copy()
    hold_target = pd.Series(1.0, index=dates)
    target.iloc[-1] = 0.0          # 期末清仓；不在终点建立新仓位
    hold_target.iloc[-1] = 0.0
    cash_daily = ((1.0 + cfg.annual_cash_return)
                  ** (1.0 / cfg.periods_per_year) - 1.0)
    fee_rate = cfg.cost_bps / 10000.0

    def apply_costs(target_weight: pd.Series):
        held = target_weight.shift(1).fillna(0.0)
        turnover = (target_weight - held).abs()
        gross = held * asset_return + (1.0 - held) * cash_daily
        fee_fraction = turnover * fee_rate
        # 先获得当日旧仓位收益，再在当日收盘成交扣费。
        net = (1.0 + gross) * (1.0 - fee_fraction) - 1.0
        return net, held, turnover, fee_fraction

    strategy, held, turnover, fee = apply_costs(target)
    buy_hold, bh_held, bh_turnover, bh_fee = apply_costs(hold_target)
    result = pd.DataFrame({
        "SMA strategy (net)": strategy,
        "Buy & hold (net)": buy_hold,
    })
    journal = pd.DataFrame({
        "PX": px.reindex(dates),
        "SMA": ma.reindex(dates),
        "Signal known at close": signal.reindex(dates),
        "Held during day": held,
        "Target after close": target,
        "Turnover at close": turnover,
        "Cost fraction": fee,
        "Asset return": asset_return,
        "Strategy net return": strategy,
        "Buy-hold held during day": bh_held,
        "Buy-hold turnover": bh_turnover,
        "Buy-hold cost fraction": bh_fee,
        "Buy-hold net return": buy_hold,
    })
    return result, journal


# %% 5. 统一执行入口与独立图表

def analyze_prices(prices: pd.DataFrame, cfg: Config) -> Dict[str, Any]:
    """也可用于离线算法测试；调用方必须明确标注输入来源。"""
    cfg.validate()
    if prices.empty or prices.isna().any().any():
        raise ValueError("价格表为空或存在缺失；请先完成数据检查。")
    if (prices <= 0).any().any() or not np.isfinite(prices.to_numpy()).all():
        raise ValueError("价格必须为正的有限数。")
    if not prices.index.is_monotonic_increasing or prices.index.has_duplicates:
        raise ValueError("日期必须严格递增且不重复。")
    prices = prices.loc[cfg.data_start:cfg.data_end].copy()
    all_returns = prices.pct_change(fill_method=None)
    returns = all_returns.loc[cfg.evaluation_start:cfg.data_end]
    summary = performance_stats(returns, cfg.periods_per_year, cfg.annual_rf)
    benchmark = returns[cfg.benchmark]
    variance = benchmark.var(ddof=1)
    if variance > 1e-12:
        summary["Beta vs benchmark"] = returns.apply(
            lambda x: x.cov(benchmark) / variance
        )
    else:
        summary["Beta vs benchmark"] = np.nan
    bt, journal = run_sma_backtest(prices, cfg)
    snapshot = factor_snapshot(prices, cfg.periods_per_year)
    return {
        "prices": prices,
        "returns": returns,
        "summary": summary,
        "correlation": returns.corr(),
        "factor_snapshot": snapshot,
        "backtest_returns": bt,
        "backtest_summary": performance_stats(bt, cfg.periods_per_year, cfg.annual_rf),
        "trade_journal": journal,
    }


def plot_results(results: Dict[str, Any]) -> None:
    """每张图单独创建；图上包含评估前一交易日的初始净值 1。"""
    prices = results["prices"]
    for key, title in [
        ("returns", "PX_LAST series comparison (not verified total return)"),
        ("backtest_returns", "SMA backtest: after modeled costs"),
    ]:
        r = results[key]
        nav = (1.0 + r).cumprod()
        prior = prices.index[prices.index < r.index[0]]
        if len(prior):
            baseline = pd.DataFrame(1.0, index=[prior[-1]], columns=r.columns)
            nav = pd.concat([baseline, nav])
        fig, ax = plt.subplots(figsize=(10, 4))
        nav.plot(ax=ax)
        ax.set(title=title, xlabel="Date", ylabel="Growth of 1")
        ax.grid(alpha=0.25)
        fig.tight_layout()
        plt.show()
    nav = (1.0 + results["backtest_returns"]).cumprod()
    drawdown = nav / nav.cummax().clip(lower=1.0) - 1.0
    fig, ax = plt.subplots(figsize=(10, 4))
    drawdown.plot(ax=ax)
    ax.set(title="Backtest drawdown", xlabel="Date", ylabel="Drawdown (decimal)")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    plt.show()


def run(cfg: Optional[Config] = None, make_plots: bool = True) -> Dict[str, Any]:
    cfg = cfg or Config()
    warnings.warn(
        "教学示例：PX_LAST 的分红/复权口径须核对；成交量日历不能替代正式交易所日历；"
        "没有计入真实滑点、税费、市场冲击或成交限制。", UserWarning
    )
    prices, diagnostics = load_bloomberg_prices(cfg)
    results = analyze_prices(prices, cfg)
    results["data_diagnostics"] = diagnostics
    print("Data range: %s to %s | Observed sessions: %d"
          % (prices.index[0].date(), prices.index[-1].date(), len(prices)))
    print("Evaluation: %s to %s | PX_LAST series basis"
          % (results["returns"].index[0].date(), results["returns"].index[-1].date()))
    for name in ["data_diagnostics", "summary", "correlation", "factor_snapshot",
                 "backtest_summary"]:
        print("\n" + name)
        print(results[name].round(4).to_string())
    if make_plots:
        plot_results(results)
    return results


if __name__ == "__main__":
    results = run()
