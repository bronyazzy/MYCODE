# Bloomberg BQNT 量化分析培训代码

## 文件与运行

`bqnt_quant_training.ipynb` 是独立 Notebook，包含全部函数，不必另外加载 `.py`。
`bqnt_quant_training.py` 是同一套逻辑的 Python 模块，可导入复用，也可在授权的 BQuant 环境直接运行。

在 BQNT 中打开 Notebook，按顺序运行代码单元。或将 `.py` 放到当前工作目录后运行：

```python
from bqnt_quant_training import Config, run

cfg = Config(
    tickers=("SPY US Equity", "QQQ US Equity", "IWM US Equity"),
    benchmark="SPY US Equity",
    strategy_ticker="SPY US Equity",
    data_start="2022-01-01",
    evaluation_start="2023-01-01",
    data_end="2025-12-31",
    sma_days=60,
    cost_bps=5.0,
    annual_rf=0.0,
    annual_cash_return=0.0,
)
results = run(cfg)
```

需要 numpy、pandas、matplotlib，以及 Bloomberg 提供的 `bql` 模块和相应数据权限。
不要因为遇到 `ModuleNotFoundError: bql` 就从不明来源安装同名包，应先核对 BQuant kernel。
代码不下单，不自动保存或向外传输 Bloomberg 数据。

## 输出

| 对象 | 内容 |
|---|---|
| `results['data_diagnostics']` | 基准观察交易日数、可用价格数、缺失价格数 |
| `results['summary']` | 累计收益、观测期年化复合收益、年化波动率、Sharpe、最大回撤、Beta |
| `results['correlation']` | 同一日期样本上的日收益 Pearson 相关矩阵 |
| `results['factor_snapshot']` | 样本末日的 21/63/126 交易日动量，以及 63 日年化波动率 |
| `results['backtest_summary']` | 均线策略与买入持有的扣费后指标 |
| `results['trade_journal']` | 收盘时已知信号、当日持仓、收盘目标仓位、换手、费用和日收益 |

程序生成三个独立图表：样本价格序列变化、扣费后回测净值、回撤。不会附带伪造的实际市场结果。

## 数据口径与限制

本例使用 `PX_LAST` 返回的序列。没有另行加载现金分红，也没有在真实账户内核对复权参数；因此不把计算结果声明为含分红总回报。应先与培训师确认拆股、分红、币种、报价源和历史修订口径，再用于正式研究。

样本仅作同市场、USD 口径教学使用。以基准 `PX_VOLUME > 0` 的工作日建立观察日历，不把周末零收益纳入 252 日年化。此方法不等于正式交易所日历：若基准本身漏数，仍需与交易所交易日历核对。任何样本在观察日历上的价格缺口都会报错，不前向填充，不事后删除后跨缺口计算“日收益”。

如果改成港股、A 股、跨市场资产、期货或债券，不应仅替换 ticker；交易日历、币种、现金流、展期、价格含义和可交易性也需要改造。固定事后选定的样本不是无幸存者偏差的历史股票池。

## 指标定义

每日收益为 `P[t] / P[t-1] - 1`，内部使用小数。
累计收益为 `prod(1 + r) - 1`。
年化复合收益为 `prod(1 + r) ** (252 / n) - 1`，其中 `n` 是日收益观测数；它不是按精确日历天数定义的 CAGR。
波动率为 `std(r, ddof=1) * sqrt(252)`。
日无风险收益为 `(1 + annual_rf) ** (1 / 252) - 1`。
Sharpe 为 `mean(r - rf_daily) / std(r - rf_daily, ddof=1) * sqrt(252)`；零波动时返回 NaN。平方根年化是统计近似，不能自动消除自相关影响。
最大回撤将评估开始前的净值 1 纳入历史峰值，因此首日亏损不会被忽略。
Beta 为 `cov(r_asset, r_benchmark) / var(r_benchmark)`；本例无风险利率为常数，因此与扣除该常数后的协方差计算一致。

`annual_rf=0` 与 `annual_cash_return=0` 都是教学假设，不是对当前市场利率的判断。

## 回测成交时序

规则是价格高于 60 日均线时目标为全仓，否则为现金。没有做空、杠杆或参数优化。

在 t-1 日收盘后获得信号，在 t 日收盘执行，新的仓位参与 t 收盘到 t+1 收盘的收益。代码中 `signal.shift(1)` 是当天收盘的目标；`target.shift(1)` 是当天收益区间内的持仓。评估首日从现金开始，预热数据只用于计算信号，不偷偷继承预热期持仓。

费用按本例定义：每次从全现金切换至全仓、或从全仓切换至现金，按交易前组合净值扣 `cost_bps / 10000`。净收益公式为 `(1 + gross_return) * (1 - turnover * fee_rate) - 1`。这是净值比例费用模型，不是逐笔实际佣金估计。

策略和买入持有都在评估首日或之后的收盘执行初始交易，最后一个评估日收盘强制清仓并扣费。代码未模拟成交失败、真实滑点、税费、市场冲击、成交量限制或收盘撮合差异。

## 培训现场核对

1. `PX_LAST` 的分红和拆股复权究竟如何设置？如何替换为已验证的总回报序列？
2. 当前账户是否支持示例中的 `dates`、`currency`、`fill` 参数？BQL 的 `DATE`、`ID` 和返回别名是什么结构？
3. 如何使用正式交易所日历，识别停牌、退市及历史漏数？
4. 扩展为选股策略时，怎样取得历史时点可获得的成分股和财务数据，而不是今天的成分和修订值？
5. 真实的下一交易日收盘、开盘或 VWAP 成交模型应怎样实现？

## 验证状态

已在离线 Python 环境对 18 项纯合成数据测试进行验证，包括累计/年化收益、首日回撤、Sharpe、重复记录、缺失数据、信号延迟、交易费用、期末清仓，以及未来价格修改不影响此前仓位。
当前编写环境没有 Bloomberg 登录会话，未测试实际 BQL 连接、字段权限、返回元数据和真实市场价格。

复核测试：`python -m unittest test_bqnt_quant_training -v`。测试不需要 Bloomberg，不应把其输入或输出当作市场数据。

## 参考资料

- Bloomberg 官方 BQuant 产品说明（平台与权限范围，非此代码的逐行接口证明）：https://professional.bloomberg.com/products/bloomberg-terminal/research/bquant/
- pandas `pct_change`：https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.pct_change.html
- pandas `pivot`：https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.pivot.html
- pandas `shift`：https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.shift.html
- pandas `corr`：https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.corr.html
- William F. Sharpe, The Sharpe Ratio, 1994：https://web.stanford.edu/~wfsharpe/art/sr/SR.htm

查询日期：2026-09-27。BQL 的具体字段帮助和账户能力仍以你的 Bloomberg 环境为准。
