# BQNT 债券量化培训代码

## 打开哪一个文件

优先打开 `BQNT_Bond_Quant_Training_CN.ipynb`：完整独立Notebook，有中文说明、配置、数据诊断、图形和所有函数，不需要额外上传Python模块。

`bqnt_bond_quant.py` 是同一套函数的可复用模块；直接运行时只生成、打印模拟结果。
`test_bqnt_bond_quant.py` 是本地测试；需要pytest，不是Notebook运行依赖。

## 默认演示

Notebook保持 `DEMO_MODE=True`，从上到下运行。所有债券、价格、OAS和历史序列均为人工构造，不是Bloomberg数据。
标准化敞口为每只债100万美元脏价市值，不是100万美元面值，也不是真实持仓。
模块依赖numpy、pandas；绘图需要matplotlib。

## 接入真实Bloomberg数据

在已授权BQuant环境中，将 `DEMO_MODE=False`，填入从Terminal确认的债券ID；先用1–2只测试取数。
查看diagnostics、snapshot和raw_tables，并在default_fields()核对/调整字段及参数。
本例不假设PX_LAST和默认YTM/OAS/久期采用同一个价格源；price不参与持仓市值计算。

候选字段：name、crncy、maturity、px_last、yield_(yield_type="YTM")、duration(duration_type="MODIFIED")、spread(spread_type="OAS")。
这些调用没有在你的账户实测。字段名称、参数、历史可用性、单位和entitlements须在本机BQL文档核对。
不要用任意同名PyPI包替代Bloomberg环境中的bql。

完成币种、同质债券组、条款、单位、价源、时间戳、结算口径和时效复核后，把LIVE_INPUTS_REVIEWED改为True。
将同质债券样本扩大到至少8只用于相对价值拟合。其他模块可在更小样本下使用。
缺失字段不会被填零，重复ID或ID/DATE不会被静默去重、平均。

## 单位与风险

价格按每100面值显示，YTM的5表示5%，OAS以bp计，久期以年计。
通过UNIT_SCALE显式转换返回单位，不能按数值大小猜测。
market_values输入含应计利息的脏价市值，以实际返回ID为键；多头正、空头负。

Yield DV01 = dirty MV × modified duration × 0.0001。
这个指标针对债券自身YTM，不自动等于固定OAS下的曲线DV01或信用CS01。
真实因子情景必须独立提供rate_duration与spread_duration。真实二阶情景必须提供已验证的yield_convexity=P''(y)/P(y)，y用小数。
没有确认缩放之前，不能直接把供应商凸性数字塞进公式。

## 相对价值和历史统计

相对价值模型只拟合OAS与标准化修正久期的二次关系。
loo_residual_bps = 实际OAS − 剔除该债后的模型预测OAS。
正数只是相对该模型更宽，不是买入指令，也没有证明会收敛；未控制所有票息、流动性或发行条款差异。

历史Z-score基准使用shift(1)，不包含当天；不填补缺失，零波动不产生分数。
窗口长度为返回矩阵的观测行数，不自动等于交易日；±2只是参考线。
没有实现总收益回测、平稳性验证或交易成本模拟，不应宣称策略有效。

## 验证状态

本地通过17项测试：付息日债券价格/久期/凸性有限差分，DV01与正负持仓的单位和符号，
留一法与逐只重新拟合对照，缺失值及币种检查，独立利率/利差情景，
滞后历史窗口，重复响应/ID解析和元数据保留。

还执行了完整Notebook的模拟流程。真实Bloomberg请求没有执行；模拟响应解析测试不构成Bloomberg集成测试。
运行测试：`pytest -q test_bqnt_bond_quant.py`。

## 培训资料

Bloomberg BQuant产品环境、固收BQL说明和CFA久期/凸性资料地址在Notebook最后的SOURCES字典。
较早的Bloomberg固收产品说明不是当前BQL字段参考手册。

本包没有下单代码，不会自动导出真实Bloomberg数据。
