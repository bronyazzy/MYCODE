"""BQNT 债券量化培训：数据诊断、相对价值、风险与历史利差。

默认演示数据均为人工构造，不是 Bloomberg 数据；无下单或交易接口。
Bloomberg 查询需在已授权 BQuant 环境中运行，并在当地 BQL 文档中核对字段。
依赖：numpy, pandas；绘图额外需要 matplotlib；实盘取数需要 Bloomberg 的 bql。

单位约定：价格=每100面值，YTM=百分数(5表示5%)，OAS=bp，久期=年，
市值=含应计利息的脏价市值(多头正、空头负)，凸性=P''(y)/P(y)，y为小数。
"""
from __future__ import annotations

from typing import Any, Callable, Dict, Mapping, Optional, Sequence, Tuple
import numpy as np
import pandas as pd

# %% BQL 数据层：仅这一部分依赖 Bloomberg。
def connect_bql() -> Any:
    """不要用任意同名 PyPI 包替代 Bloomberg 环境中的 bql。"""
    try:
        import bql
    except ImportError as exc:
        raise RuntimeError("请在 Bloomberg BQuant 的已授权 Python 环境中运行实时查询。") from exc
    if not hasattr(bql, "Service"):
        raise RuntimeError("当前导入的 bql 不是所需的 Bloomberg BQL 库。")
    return bql.Service()


def default_fields(bq: Any) -> Dict[str, Callable[[], Any]]:
    """候选字段映射；培训时核对名称、参数、价格来源、结算日和单位。

    lambda 使某一个字段不支持时仍能返回其他字段的诊断信息。
    price 仅供展示；不假设 PX_LAST 与默认收益率/OAS采用同一报价源。
    """
    return {
        "name": lambda: bq.data.name(),
        "currency": lambda: bq.data.crncy(),
        "maturity": lambda: bq.data.maturity(),
        "price": lambda: bq.data.px_last(),
        "ytm_pct": lambda: bq.data.yield_(yield_type="YTM"),
        "mod_duration": lambda: bq.data.duration(duration_type="MODIFIED"),
        "oas_bps": lambda: bq.data.spread(spread_type="OAS"),
    }


def _ids(ids: Sequence[str]) -> list:
    if isinstance(ids, str):
        raise TypeError("请传入债券ID列表，而不是单个字符串。")
    values = [str(v).strip() for v in ids]
    if not values or any(not v for v in values):
        raise ValueError("债券ID列表不能为空。")
    if len(values) != len(set(values)):
        raise ValueError("债券ID重复；请先去重。")
    return values


def fetch_snapshot(
    bq: Any, bond_ids: Sequence[str],
    fields: Optional[Mapping[str, Callable[[], Any]]] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, pd.DataFrame]]:
    """按字段批量查询全部债券，不逐只债券查询。

    返回 snapshot, diagnostics, raw_tables。保留各字段的DATE等元数据。
    不把失败字段填零；不静默去重；使用实际返回的ID，不假设ID不会标准化。
    此逐字段方式用于小样本培训诊断；字段确认后可合并为一次Request。
    """
    import bql
    bond_ids = _ids(bond_ids)
    builders = default_fields(bq) if fields is None else dict(fields)
    pieces, diagnostics, raw_tables = [], [], {}
    for alias, build in builders.items():
        try:
            response = bq.execute(bql.Request(bond_ids, {alias: build()}))
            if len(response) != 1:
                raise ValueError("单字段查询返回项数不是1。")
            item = response[0]
            raw = item.df().copy()
            raw_tables[alias] = raw
            frame = raw.set_index("ID") if "ID" in raw.columns else raw
            if frame.index.nlevels != 1 or frame.index.has_duplicates:
                raise ValueError("同一ID返回多行；请核对日期/报价源，不能直接拼接。")
            if frame.empty or item.name not in frame.columns:
                raise ValueError("没有可识别的数值列或返回为空。")
            out = frame[[item.name]].rename(columns={item.name: alias})
            meta = frame.drop(columns=[item.name]).add_prefix(alias + "__")
            pieces.append(pd.concat([out, meta], axis=1))
            diagnostics.append({"field": alias, "status": "OK", "rows": len(frame),
                                "non_null": int(out[alias].notna().sum()), "error": ""})
        except Exception as exc:
            diagnostics.append({"field": alias, "status": "ERROR", "rows": 0,
                                "non_null": 0, "error": str(exc)})
    snapshot = pd.concat(pieces, axis=1) if pieces else pd.DataFrame()
    snapshot.index.name = "ID"
    return snapshot, pd.DataFrame(diagnostics), raw_tables


def fetch_oas_history(
    bq: Any, bond_ids: Sequence[str], start: str = "-1Y", end: str = "0D",
    field_builder: Optional[Callable[[Any], Any]] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """返回DATE×ID的OAS矩阵及原始响应；不做前向填充或重复行平均。

    dates/fill参数也需在本机BQL文档确认。元数据的DATE不一定是原始报价时间。
    field_builder可用于替换为培训老师确认的完整历史表达式。
    """
    import bql
    ids = _ids(bond_ids)
    field = (field_builder(bq) if field_builder else
             bq.data.spread(spread_type="OAS", dates=bq.func.range(start, end), fill="NA"))
    response = bq.execute(bql.Request(ids, {"oas_bps": field}))
    if len(response) != 1:
        raise ValueError("历史查询返回项数不是1。")
    item = response[0]
    raw = item.df().copy()
    flat = raw.copy() if "ID" in raw.columns else raw.reset_index()
    needed = {"ID", "DATE", item.name}
    if not needed.issubset(flat.columns):
        raise ValueError("历史响应缺少ID、DATE或数值列；请检查原始响应。")
    flat["DATE"] = pd.to_datetime(flat["DATE"], errors="raise")
    if flat["DATE"].isna().any() or flat["ID"].isna().any():
        raise ValueError("历史响应包含缺失的ID或DATE。")
    if flat.duplicated(["ID", "DATE"]).any():
        raise ValueError("同一ID/DATE返回多行，需先明确报价来源；不能静默取平均。")
    flat[item.name] = pd.to_numeric(flat[item.name], errors="coerce")
    history = flat.pivot(index="DATE", columns="ID", values=item.name).sort_index()
    return history, raw

# %% 数据质量与相对价值：普通Python即可运行。
def validate_snapshot(
    snapshot: pd.DataFrame, currency: str = "USD",
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """基础数值筛查；不替代条款、报价时效、来源、单位或可比组的人工复核。

    负OAS不自动删除。无效行单独返回，不能把缺失利差填成零。
    """
    required = ["currency", "mod_duration", "oas_bps"]
    missing = [c for c in required if c not in snapshot]
    if missing:
        raise ValueError("缺少必要字段，请先看diagnostics：" + ", ".join(missing))
    if snapshot.empty or snapshot.index.has_duplicates or snapshot.index.isna().any():
        raise ValueError("快照为空、ID重复或ID缺失。")
    df = snapshot.copy()
    for col in ["mod_duration", "oas_bps", "ytm_pct", "price"]:
        if col in df:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df["currency"] = df["currency"].astype("string").str.strip().str.upper()
    flags = pd.DataFrame(index=df.index)
    flags["invalid_duration"] = (~np.isfinite(df["mod_duration"]) | (df["mod_duration"] <= 0))
    flags["invalid_oas"] = ~np.isfinite(df["oas_bps"])
    flags["currency_mismatch_or_missing"] = df["currency"].ne(currency.upper()).fillna(True)
    rejected_mask = flags.any(axis=1)
    rejected = df.loc[rejected_mask].copy()
    rejected["reason"] = flags.loc[rejected_mask].apply(
        lambda row: "; ".join(row.index[row.to_numpy(dtype=bool)]), axis=1)
    clean = df.loc[~rejected_mask].copy()
    if clean.empty:
        raise ValueError("筛查后没有可分析的债券。")
    if "name" not in clean:
        clean["name"] = clean.index.astype(str)
    return clean, rejected


def fit_relative_value(
    df: pd.DataFrame, min_bonds: int = 8, max_leverage: float = 0.95,
) -> Tuple[pd.DataFrame, dict]:
    """同质可比组内拟合 OAS = b0 + b1*x + b2*x²，x为标准化修正久期。

    LOO残差=实际OAS-剔除自身后的模型预测。正数仅表示相对模型更宽。
    高杠杆点不输出LOO评分；这不是违约概率、alpha检验或交易建议。
    """
    if len(df) < max(5, min_bonds):
        raise ValueError("相对价值拟合至少需要%d只可比债券。" % max(5, min_bonds))
    if not 0 < max_leverage < 1:
        raise ValueError("max_leverage必须在0和1之间。")
    duration = df["mod_duration"].to_numpy(dtype=float)
    y = df["oas_bps"].to_numpy(dtype=float)
    if not np.isfinite(duration).all() or not np.isfinite(y).all():
        raise ValueError("拟合输入存在NaN或无穷值。")
    center, scale = float(duration.mean()), float(duration.std(ddof=0))
    if scale < 1e-8:
        raise ValueError("久期变化不足，无法识别曲线。")
    x = (duration - center) / scale
    X = np.column_stack([np.ones(len(x)), x, x*x])
    beta, _, rank, _ = np.linalg.lstsq(X, y, rcond=None)
    if rank != 3 or np.linalg.cond(X) > 1e8:
        raise ValueError("模型矩阵秩不足或病态；请增加不同期限债券或改用线性模型。")
    Q, _ = np.linalg.qr(X, mode="reduced")
    leverage = (Q * Q).sum(axis=1)
    residual = y - X @ beta
    reliable = leverage < max_leverage
    loo = np.full(len(df), np.nan)
    loo[reliable] = residual[reliable] / (1.0 - leverage[reliable])
    result = df.copy()
    result["fitted_oas_bps"] = X @ beta
    result["residual_bps"] = residual
    result["leverage"] = leverage
    result["loo_residual_bps"] = loo
    result["loo_fair_oas_bps"] = y - loo
    result["loo_reliable"] = reliable
    result = result.sort_values("loo_residual_bps", ascending=False, na_position="last")
    model = {"beta": beta, "duration_center": center, "duration_scale": scale,
             "n_bonds": len(df), "residual_rmse_bps": float(np.sqrt(np.mean(residual**2)))}
    return result, model

# %% 风险：收益率DV01与利率曲线DV01、CS01严格分开。
def attach_risk(
    df: pd.DataFrame, market_values: Optional[Mapping[str, float]] = None,
    normalized_mv: float = 1_000_000.0, extra_risk: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    """market_values=None时，每只债券配置假设的100万脏价市值，不是真实持仓。

    输入真实市值时，键必须是实际返回ID；未列出的债券按零仓位处理。
    extra_risk可含 rate_duration, spread_duration, yield_convexity，必须已核对口径。
    yield_convexity要求y使用小数时的P''/P；不自动缩放Bloomberg凸性字段。
    """
    if df.empty or df.index.has_duplicates:
        raise ValueError("风险输入为空或ID重复。")
    if "currency" not in df or df["currency"].isna().any() or df["currency"].nunique() != 1:
        raise ValueError("必须先限制为单一币种；本例不做FX转换。")
    out = df.copy()
    if market_values is None:
        if not np.isfinite(normalized_mv) or normalized_mv <= 0:
            raise ValueError("假设市值必须是正的有限数值。")
        out["dirty_mv"] = float(normalized_mv)
        out["exposure_mode"] = "HYPOTHETICAL_EQUAL_DIRTY_MV"
    else:
        if not market_values:
            raise ValueError("市值映射为空；标准化演示请显式传入None。")
        unknown = set(market_values) - set(out.index)
        if unknown:
            raise ValueError("持仓ID未出现在有效快照中（可能被剔除）：" + str(sorted(unknown)))
        mv = pd.Series(market_values, dtype=float)
        if not np.isfinite(mv).all():
            raise ValueError("持仓市值有NaN或无穷值。")
        out["dirty_mv"] = mv.reindex(out.index, fill_value=0.0)
        out["exposure_mode"] = "USER_SUPPLIED_DIRTY_MV"
    if not np.isfinite(out["mod_duration"]).all() or (out["mod_duration"] <= 0).any():
        raise ValueError("修正久期无效。")
    out["yield_dv01"] = out["dirty_mv"] * out["mod_duration"] * 1e-4
    if extra_risk is not None:
        if extra_risk.index.has_duplicates:
            raise ValueError("额外风险数据ID重复。")
        for col in ["rate_duration", "spread_duration", "yield_convexity"]:
            if col in extra_risk:
                out[col] = pd.to_numeric(extra_risk[col], errors="raise").reindex(out.index)
    if "rate_duration" in out:
        out["rate_dv01"] = out["dirty_mv"] * out["rate_duration"] * 1e-4
    if "spread_duration" in out:
        out["cs01"] = out["dirty_mv"] * out["spread_duration"] * 1e-4
    return out


def yield_scenarios(
    risk: pd.DataFrame, shocks_bps: Sequence[float] = (-100, -50, -25, 0, 25, 50, 100),
    use_convexity: bool = False,
) -> pd.DataFrame:
    """每只债券的自身YTM同幅变化；非无风险曲线/信用利差独立冲击。

    P&L≈-MV*Dmod*dy+0.5*MV*C*dy²；忽略时间流逝、票息、融资、交易成本。
    """
    shock = np.asarray(shocks_bps, dtype=float)
    if shock.ndim != 1 or not len(shock) or not np.isfinite(shock).all():
        raise ValueError("冲击应为非空的一维有限数值列表，单位bp。")
    active = risk.loc[risk["dirty_mv"] != 0]
    needed = ["dirty_mv", "mod_duration"] + (["yield_convexity"] if use_convexity else [])
    if active.empty or any(c not in active for c in needed):
        raise ValueError("没有非零持仓，或缺少所需风险字段。")
    if not np.isfinite(active[needed].to_numpy(dtype=float)).all():
        raise ValueError("非零持仓风险字段不完整；不能忽略缺失后汇总。")
    dy = shock * 1e-4
    linear = -float((active["dirty_mv"] * active["mod_duration"]).sum()) * dy
    result = pd.DataFrame({"yield_shock_bps": shock, "linear_pnl": linear})
    if use_convexity:
        adjustment = 0.5 * float((active["dirty_mv"] * active["yield_convexity"]).sum()) * dy**2
        result["convexity_adjustment"] = adjustment
        result["duration_convexity_pnl"] = linear + adjustment
    return result


def factor_scenarios(risk: pd.DataFrame, scenarios: pd.DataFrame) -> pd.DataFrame:
    """需独立提供rate_duration和spread_duration；绝不以修正久期静默替代。

    scenarios索引为场景名，列为rate_bps和spread_bps。仅一阶近似，无交叉凸性。
    """
    cols = ["dirty_mv", "rate_duration", "spread_duration"]
    if any(c not in risk for c in cols):
        raise ValueError("需先提供已验证的rate_duration和spread_duration。")
    active = risk.loc[risk["dirty_mv"] != 0, cols]
    if active.empty or not np.isfinite(active.to_numpy(dtype=float)).all():
        raise ValueError("非零持仓的曲线/利差久期不完整。")
    if not {"rate_bps", "spread_bps"}.issubset(scenarios.columns) or scenarios.empty:
        raise ValueError("场景需要rate_bps和spread_bps两列。")
    if not np.isfinite(scenarios[["rate_bps", "spread_bps"]].to_numpy(dtype=float)).all():
        raise ValueError("场景冲击含NaN或无穷值。")
    dv01 = float((active["dirty_mv"] * active["rate_duration"]).sum()) * 1e-4
    cs01 = float((active["dirty_mv"] * active["spread_duration"]).sum()) * 1e-4
    out = scenarios.copy()
    out["rate_pnl"] = -dv01 * out["rate_bps"]
    out["spread_pnl"] = -cs01 * out["spread_bps"]
    out["total_pnl"] = out["rate_pnl"] + out["spread_pnl"]
    return out


def pair_zscore(history: pd.DataFrame, bond_a: str, bond_b: str, window: int = 60) -> pd.DataFrame:
    """Z=(当天A-B利差差值-此前window行均值)/此前window行样本标准差。

    shift(1)将当天排除在基准窗口之外；不填补缺失；标准差为0时不出分数。
    window指返回矩阵的观测行数，不自动代表交易日。不是回测或收益预测。
    """
    if not isinstance(window, int) or window < 2 or bond_a == bond_b:
        raise ValueError("窗口至少为2且债券A、B必须不同。")
    if history.columns.has_duplicates or not {bond_a, bond_b}.issubset(history.columns):
        raise ValueError("历史矩阵列重复或未找到所选实际返回ID。")
    h = history[[bond_a, bond_b]].copy()
    h.index = pd.to_datetime(h.index, errors="raise")
    if h.index.has_duplicates or h.index.isna().any():
        raise ValueError("历史日期重复或缺失。")
    h = h.sort_index().apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
    gap = h[bond_a] - h[bond_b]
    past = gap.shift(1)
    mean = past.rolling(window, min_periods=window).mean()
    std = past.rolling(window, min_periods=window).std(ddof=1)
    z = (gap - mean) / std.where(std > 1e-12)
    return pd.DataFrame({"gap_bps": gap, "past_mean_bps": mean,
                         "past_std_bps": std, "zscore": z})

# %% 完全人工构造的数据：演示与单元测试。
def coupon_date_metrics(coupon_pct: float, ytm_pct: float, years: float, frequency: int = 2) -> dict:
    """仅限恰在付息日、等间隔现金流、到期还本100的教学模型。

    无日计数、节假日、零碎票息或应计利息处理；不用于代替真实债券定价引擎。
    """
    if frequency not in (1, 2, 4, 12) or not np.isfinite([coupon_pct, ytm_pct, years]).all():
        raise ValueError("频率或输入无效。")
    if coupon_pct < 0 or years <= 0 or not np.isclose(years * frequency, round(years * frequency)):
        raise ValueError("需非负票息、正期限与完整付息期。")
    n = int(round(years * frequency))
    base = 1.0 + ytm_pct / 100.0 / frequency
    if base <= 0:
        raise ValueError("复利基数必须大于0。")
    j = np.arange(1, n + 1, dtype=float)
    cf = np.full(n, coupon_pct / frequency, dtype=float)
    cf[-1] += 100.0
    pv = cf / base**j
    price = float(pv.sum())
    duration = float((j * pv).sum() / (frequency * base * price))
    convexity = float((j * (j + 1) * pv).sum() / (frequency**2 * base**2 * price))
    return {"price": price, "mod_duration": duration, "yield_convexity": convexity}


def make_demo_data(seed: int = 42) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """虚构USD同一发行人、同一顺位、固定票息、无嵌入期权；不是市场报价。

    额外因子久期在教学假设y=r+s下均等于mod_duration；不把该假设用于实时债券。
    """
    rng = np.random.default_rng(seed)
    asof = pd.Timestamp("2026-09-25")  # 虚构数据的基准日期，不是实时行情时间。
    years = np.array([1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 15, 20], dtype=float)
    oas = 75 + 6.5 * years - 0.15 * years**2 + rng.normal(0, 3, len(years))
    oas[5] += 18
    oas[8] -= 14
    records, extra = [], []
    for i, (t, spread) in enumerate(zip(years, oas), start=1):
        sid, ytm = "DEMO_%02d" % i, 3.5 + spread / 100
        metrics = coupon_date_metrics(4.0, ytm, t)
        records.append({"ID": sid, "name": "Synthetic bond %02d" % i, "currency": "USD",
                        "maturity": asof + pd.DateOffset(years=int(t)),
                        "price": metrics["price"], "ytm_pct": ytm,
                        "mod_duration": metrics["mod_duration"], "oas_bps": spread,
                        "oas_bps__DATE": asof, "mod_duration__DATE": asof,
                        "data_source": "SYNTHETIC / NOT BLOOMBERG"})
        extra.append({"ID": sid, "rate_duration": metrics["mod_duration"],
                      "spread_duration": metrics["mod_duration"],
                      "yield_convexity": metrics["yield_convexity"]})
    snapshot = pd.DataFrame(records).set_index("ID")
    dates = pd.bdate_range(end=asof, periods=260)
    common = np.cumsum(rng.normal(0, 0.5, len(dates)))
    series = {}
    for sid, spread in zip(snapshot.index, oas):
        noise = np.zeros(len(dates))
        for k in range(1, len(noise)):
            noise[k] = 0.90 * noise[k-1] + rng.normal(0, 1.0)
        path = common + noise
        series[sid] = spread + path - path[-1]
    history = pd.DataFrame(series, index=dates)
    history.index.name = "DATE"
    return snapshot, history, pd.DataFrame(extra).set_index("ID")

# %% 可视化：不触发Bloomberg查询。
def plot_relative_value(result: pd.DataFrame, model: dict, label: str = "") -> Any:
    import matplotlib.pyplot as plt
    x = np.linspace(result["mod_duration"].min(), result["mod_duration"].max(), 150)
    z = (x - model["duration_center"]) / model["duration_scale"]
    fitted = np.column_stack([np.ones(len(x)), z, z*z]) @ model["beta"]
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.scatter(result["mod_duration"], result["oas_bps"], label="Observed OAS")
    ax.plot(x, fitted, label="In-sample reference curve")
    for sid, row in result.nlargest(3, "loo_residual_bps").iterrows():
        ax.annotate(str(sid), (row["mod_duration"], row["oas_bps"]),
                    xytext=(4, 4), textcoords="offset points", fontsize=8)
    ax.set(xlabel="Modified duration (years)", ylabel="OAS (bp)",
           title="Bond relative value " + label)
    ax.legend()
    fig.tight_layout()
    return fig


def plot_pair_zscore(pair: pd.DataFrame, label: str = "") -> Any:
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(9, 4))
    ax.plot(pair.index, pair["zscore"], label="Lagged-window Z-score")
    ax.axhline(2, linestyle="--", linewidth=1)
    ax.axhline(-2, linestyle="--", linewidth=1)
    ax.axhline(0, linestyle=":", linewidth=1)
    ax.set(xlabel="Date", ylabel="Z-score", title="OAS gap diagnostic " + label)
    ax.legend()
    fig.tight_layout()
    return fig


if __name__ == "__main__":
    print("SYNTHETIC DEMO ONLY — NOT BLOOMBERG DATA; hypothetical 1m USD dirty MV per bond")
    snapshot, history, extra = make_demo_data()
    clean, rejected = validate_snapshot(snapshot)
    rv, model = fit_relative_value(clean)
    risk = attach_risk(clean, extra_risk=extra)
    print(rv[["mod_duration", "oas_bps", "loo_residual_bps"]].round(3).to_string())
    print(yield_scenarios(risk, use_convexity=True).round(2).to_string(index=False))
    print(pair_zscore(history, "DEMO_06", "DEMO_07").tail(3).round(3).to_string())
