"""本地数学/边界/响应解析测试；模拟BQL响应不构成Bloomberg集成测试。"""
import sys
from types import SimpleNamespace
import numpy as np
import pandas as pd
import pytest
import bqnt_bond_quant as q


def test_coupon_price_duration_convexity_finite_difference():
    base = q.coupon_date_metrics(4.0, 4.5, 10)
    bump = 1e-4  # 小数收益率，即1bp；函数输入为百分数。
    down = q.coupon_date_metrics(4.0, 4.5 - bump*100, 10)["price"]
    up = q.coupon_date_metrics(4.0, 4.5 + bump*100, 10)["price"]
    d = (down-up)/(2*bump*base["price"])
    c = (down+up-2*base["price"])/(bump*bump*base["price"])
    np.testing.assert_allclose(base["mod_duration"], d, rtol=1e-6)
    np.testing.assert_allclose(base["yield_convexity"], c, rtol=1e-6)


def test_par_bond_and_invalid_inputs():
    assert q.coupon_date_metrics(5, 5, 5)["price"] == pytest.approx(100)
    with pytest.raises(ValueError):
        q.coupon_date_metrics(4, 5, 2.2)
    with pytest.raises(ValueError):
        q.coupon_date_metrics(4, -200, 2)


def test_demo_pipeline_and_no_nan_in_baseline():
    raw, history, extra = q.make_demo_data()
    clean, rejected = q.validate_snapshot(raw)
    assert len(clean) == 12 and rejected.empty
    rv, model = q.fit_relative_value(clean)
    assert rv.index[0] == "DEMO_06"
    assert model["n_bonds"] == 12
    risk = q.attach_risk(clean, extra_risk=extra)
    scenarios = q.yield_scenarios(risk, use_convexity=True)
    assert scenarios.notna().all().all()
    assert scenarios.loc[scenarios.yield_shock_bps == 25, "linear_pnl"].iloc[0] < 0
    pair = q.pair_zscore(history, "DEMO_06", "DEMO_07")
    assert pair.zscore.iloc[:60].isna().all()
    assert pair.zscore.iloc[60:].notna().all()


def test_loocv_formula_against_individual_refits():
    raw, _, _ = q.make_demo_data()
    rv, model = q.fit_relative_value(raw)
    x = (raw.mod_duration.to_numpy()-model["duration_center"])/model["duration_scale"]
    X = np.column_stack([np.ones(len(raw)), x, x*x])
    y = raw.oas_bps.to_numpy()
    for i, sid in enumerate(raw.index):
        mask = np.arange(len(raw)) != i
        beta = np.linalg.lstsq(X[mask], y[mask], rcond=None)[0]
        predicted = X[i] @ beta
        assert rv.loc[sid, "loo_fair_oas_bps"] == pytest.approx(predicted)


def test_loo_prediction_not_affected_by_own_y():
    raw, _, _ = q.make_demo_data()
    first, _ = q.fit_relative_value(raw)
    sid = "DEMO_06"
    raw.loc[sid, "oas_bps"] += 100
    second, _ = q.fit_relative_value(raw)
    assert second.loc[sid, "loo_fair_oas_bps"] == pytest.approx(first.loc[sid, "loo_fair_oas_bps"])


def test_invalid_data_report_and_negative_oas_retained():
    raw, _, _ = q.make_demo_data()
    raw.loc["DEMO_01", "oas_bps"] = np.nan
    raw.loc["DEMO_02", "mod_duration"] = 0
    raw.loc["DEMO_03", "currency"] = "EUR"
    raw.loc["DEMO_04", "oas_bps"] = -2
    clean, rejected = q.validate_snapshot(raw)
    assert len(rejected) == 3 and "DEMO_04" in clean.index
    with pytest.raises(ValueError):
        q.attach_risk(clean, market_values={"DEMO_01": 1_000_000})


def test_currency_missing_and_mixed_currency_rejected():
    raw, _, _ = q.make_demo_data()
    raw.loc["DEMO_01", "currency"] = None
    clean, rejected = q.validate_snapshot(raw)
    assert len(rejected) == 1
    with pytest.raises(ValueError):
        q.attach_risk(raw)
    raw.loc["DEMO_01", "currency"] = "EUR"
    with pytest.raises(ValueError):
        q.attach_risk(raw)


def simple_bond():
    return pd.DataFrame({"currency": ["USD"], "mod_duration": [5.0], "oas_bps": [100.0]}, index=["A"])


def test_dv01_units_long_short_zero_and_convexity():
    df = simple_bond()
    extra = pd.DataFrame({"yield_convexity": [30.0]}, index=["A"])
    risk = q.attach_risk(df, extra_risk=extra)
    assert risk.loc["A", "yield_dv01"] == pytest.approx(500)
    out = q.yield_scenarios(risk, [0, 1, 25], use_convexity=True)
    assert out.linear_pnl.tolist() == pytest.approx([0, -500, -12500])
    assert out.duration_convexity_pnl.iloc[-1] == pytest.approx(-12500+93.75)
    short = q.attach_risk(df, market_values={"A": -1_000_000})
    assert q.yield_scenarios(short, [25]).linear_pnl.iloc[0] == pytest.approx(12500)


def test_separate_rate_and_spread_durations():
    extra = pd.DataFrame({"rate_duration": [4.0], "spread_duration": [3.0]}, index=["A"])
    risk = q.attach_risk(simple_bond(), extra_risk=extra)
    out = q.factor_scenarios(risk, pd.DataFrame({"rate_bps": [25], "spread_bps": [50]}))
    assert out.rate_pnl.iloc[0] == pytest.approx(-10000)
    assert out.spread_pnl.iloc[0] == pytest.approx(-15000)
    assert out.total_pnl.iloc[0] == pytest.approx(-25000)
    with pytest.raises(ValueError):
        q.factor_scenarios(q.attach_risk(simple_bond()), out)


def test_missing_extra_risk_must_not_silently_sum():
    risk = q.attach_risk(simple_bond())
    risk["yield_convexity"] = np.nan
    with pytest.raises(ValueError):
        q.yield_scenarios(risk, use_convexity=True)
    risk["rate_duration"], risk["spread_duration"] = 4.0, np.nan
    with pytest.raises(ValueError):
        q.factor_scenarios(risk, pd.DataFrame({"rate_bps": [25], "spread_bps": [50]}))


def test_zscore_lag_and_zero_variance():
    hist = pd.DataFrame({"A": np.arange(8, dtype=float), "B": np.zeros(8)},
                        index=pd.date_range("2025-01-01", periods=8))
    out = q.pair_zscore(hist, "A", "B", window=3)
    assert out.iloc[3].past_mean_bps == pytest.approx(1)
    assert out.iloc[3].past_std_bps == pytest.approx(1)
    assert out.iloc[3].zscore == pytest.approx(2)
    hist.iloc[-1, 0] = 1000
    altered = q.pair_zscore(hist, "A", "B", window=3)
    assert out.iloc[-1].past_mean_bps == pytest.approx(altered.iloc[-1].past_mean_bps)
    hist["A"] = 5
    assert q.pair_zscore(hist, "A", "B", 3).zscore.isna().all()


def test_history_missing_observations_not_filled():
    hist = pd.DataFrame({"A": [1, 2, np.nan, 4, 5, 6, 7], "B": np.zeros(7)},
                        index=pd.date_range("2025-01-01", periods=7))
    out = q.pair_zscore(hist, "A", "B", 3)
    assert pd.isna(out.iloc[2].gap_bps)
    assert pd.isna(out.iloc[5].zscore)
    assert np.isfinite(out.iloc[6].zscore)


def test_small_sample_rank_and_high_leverage():
    raw, _, _ = q.make_demo_data()
    with pytest.raises(ValueError):
        q.fit_relative_value(raw.iloc[:3])
    raw["mod_duration"] = 5
    with pytest.raises(ValueError):
        q.fit_relative_value(raw)
    raw, _, _ = q.make_demo_data()
    raw.loc["DEMO_12", "mod_duration"] = 1000
    rv, _ = q.fit_relative_value(raw)
    assert not rv.loc["DEMO_12", "loo_reliable"]
    assert np.isnan(rv.loc["DEMO_12", "loo_residual_bps"])


class Item:
    def __init__(self, name, df):
        self.name, self._df = name, df
    def df(self):
        return self._df.copy()


def test_snapshot_adapter_metadata_and_errors(monkeypatch):
    monkeypatch.setitem(sys.modules, "bql", SimpleNamespace(Request=lambda ids, fields: (ids, fields)))
    def execute(request):
        alias = next(iter(request[1]))
        frame = pd.DataFrame({alias: [1., 2.], "DATE": pd.to_datetime(["2026-09-25"]*2)},
                             index=pd.Index(["CANON_A", "CANON_B"], name="ID"))
        return [Item(alias, frame)]
    def broken():
        raise RuntimeError("field not supported")
    df, status, raw = q.fetch_snapshot(SimpleNamespace(execute=execute), ["Input_A", "Input_B"],
                                       {"oas_bps": lambda: 1, "bad": broken})
    assert df.index.tolist() == ["CANON_A", "CANON_B"]
    assert "oas_bps__DATE" in df and "oas_bps" in raw
    assert status.status.tolist() == ["OK", "ERROR"]
    assert "bad" not in df


def test_snapshot_adapter_duplicate_rows_not_dropped(monkeypatch):
    monkeypatch.setitem(sys.modules, "bql", SimpleNamespace(Request=lambda ids, fields: (ids, fields)))
    frame = pd.DataFrame({"oas_bps": [1, 2]}, index=pd.Index(["A", "A"], name="ID"))
    service = SimpleNamespace(execute=lambda request: [Item("oas_bps", frame)])
    df, status, raw = q.fetch_snapshot(service, ["A"], {"oas_bps": lambda: 1})
    assert df.empty and status.status.iloc[0] == "ERROR"


def test_history_adapter_duplicate_rows_rejected(monkeypatch):
    monkeypatch.setitem(sys.modules, "bql", SimpleNamespace(Request=lambda ids, fields: (ids, fields)))
    frame = pd.DataFrame({"DATE": pd.to_datetime(["2026-09-25"]*2), "oas_bps": [100, 101]},
                         index=pd.Index(["A", "A"], name="ID"))
    service = SimpleNamespace(execute=lambda request: [Item("oas_bps", frame)])
    with pytest.raises(ValueError):
        q.fetch_oas_history(service, ["A"], field_builder=lambda bq: 1)


def test_history_adapter_pivots_by_date_and_id(monkeypatch):
    monkeypatch.setitem(sys.modules, "bql", SimpleNamespace(Request=lambda ids, fields: (ids, fields)))
    frame = pd.DataFrame({"DATE": pd.to_datetime(["2026-09-25", "2026-09-24", "2026-09-25"]),
                          "oas_bps": [100, 99, 150]},
                         index=pd.Index(["A", "A", "B"], name="ID"))
    service = SimpleNamespace(execute=lambda request: [Item("oas_bps", frame)])
    hist, _ = q.fetch_oas_history(service, ["A", "B"], field_builder=lambda bq: 1)
    assert hist.loc["2026-09-24", "A"] == 99
    assert np.isnan(hist.loc["2026-09-24", "B"])
